(function() {
	Date.shortMonths = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
	Date.longMonths = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
	Date.shortDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
	Date.longDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
// defining patterns
var replaceChars = {
	// Day
	d: function() { return (this.getDate() < 10 ? '0' : '') + this.getDate(); },
	D: function() { return Date.shortDays[this.getDay()]; },
	j: function() { return this.getDate(); },
	l: function() { return Date.longDays[this.getDay()]; },
	N: function() { return this.getDay() + 1; },
	S: function() { return (this.getDate() % 10 == 1 && this.getDate() != 11 ? 'st' : (this.getDate() % 10 == 2 && this.getDate() != 12 ? 'nd' : (this.getDate() % 10 == 3 && this.getDate() != 13 ? 'rd' : 'th'))); },
	w: function() { return this.getDay(); },
	z: function() { var d = new Date(this.getFullYear(),0,1); return Math.ceil((this - d) / 86400000); }, // Fixed now
	// Week
	W: function() { var d = new Date(this.getFullYear(), 0, 1); return Math.ceil((((this - d) / 86400000) + d.getDay() + 1) / 7); }, // Fixed now
	// Month
	F: function() { return Date.longMonths[this.getMonth()]; },
	m: function() { return (this.getMonth() < 9 ? '0' : '') + (this.getMonth() + 1); },
	M: function() { return Date.shortMonths[this.getMonth()]; },
	n: function() { return this.getMonth() + 1; },
	t: function() { var d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 0).getDate() }, // Fixed now, gets #days of date
	// Year
	L: function() { var year = this.getFullYear(); return (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)); }, // Fixed now
	o: function() { var d = new Date(this.valueOf()); d.setDate(d.getDate() - ((this.getDay() + 6) % 7) + 3); return d.getFullYear();}, //Fixed now
	Y: function() { return this.getFullYear(); },
	y: function() { return ('' + this.getFullYear()).substr(2); },
	// Time
	a: function() { return this.getHours() < 12 ? 'am' : 'pm'; },
	A: function() { return this.getHours() < 12 ? 'AM' : 'PM'; },
	B: function() { return Math.floor((((this.getUTCHours() + 1) % 24) + this.getUTCMinutes() / 60 + this.getUTCSeconds() / 3600) * 1000 / 24); }, // Fixed now
	g: function() { return this.getHours() % 12 || 12; },
	G: function() { return this.getHours(); },
	h: function() { return ((this.getHours() % 12 || 12) < 10 ? '0' : '') + (this.getHours() % 12 || 12); },
	H: function() { return (this.getHours() < 10 ? '0' : '') + this.getHours(); },
	i: function() { return (this.getMinutes() < 10 ? '0' : '') + this.getMinutes(); },
	s: function() { return (this.getSeconds() < 10 ? '0' : '') + this.getSeconds(); },
	u: function() { var m = this.getMilliseconds(); return (m < 10 ? '00' : (m < 100 ?
	'0' : '')) + m; },
	// Timezone
	e: function() { return "Not Yet Supported"; },
	I: function() {
	var DST = null;
	for (var i = 0; i < 12; ++i) {
	var d = new Date(this.getFullYear(), i, 1);
	var offset = d.getTimezoneOffset();
	if (DST === null) DST = offset;
	else if (offset < DST) { DST = offset; break; } else if (offset > DST) break;
	}
	return (this.getTimezoneOffset() == DST) | 0;
	},
	O: function() { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + '00'; },
	P: function() { return (-this.getTimezoneOffset() < 0 ? '-' : '+') + (Math.abs(this.getTimezoneOffset() / 60) < 10 ? '0' : '') + (Math.abs(this.getTimezoneOffset() / 60)) + ':00'; }, // Fixed now
	T: function() { return this.toTimeString().replace(/^.+ \(?([^\)]+)\)?$/, '$1'); },
	Z: function() { return -this.getTimezoneOffset() * 60; },
	// Full Date/Time
	c: function() { return this.format("Y-m-d\\TH:i:sP"); }, // Fixed now
	r: function() { return this.toString(); },
	U: function() { return this.getTime() / 1000; }
};
// Simulates PHP's date function
Date.prototype.format = function(format) {
	var date = this;
	return format.replace(/(\\?)(.)/g, function(_, esc, chr) {
	return (esc === '' && replaceChars[chr]) ? replaceChars[chr].call(date) : chr;
	});
};
}).call(this);

var maskToPattern = function(value, pattern) {
    var output = pattern.split(""),
        values = value.toString().replace(/[^0-9a-zA-Z]/g, ""),
        index = 0,i,maskDigit="9",maskAlpha="A";
    for (i = 0; i < output.length; i++) {
      if (index >= values.length) {break;}
      if ((output[i] === maskDigit && values[index].match(/[0-9]/)) ||
          (output[i] === maskAlpha && values[index].match(/[a-zA-Z]/))) {
        output[i] = values[index++];
      } else if (output[i] === maskDigit || output[i] === maskAlpha) {
        output = output.slice(0, i);
      }
    }
    return output.join("").substr(0, i);
},toMoney = function(value,precision,separator,delimiter,unit,zeroCents) {
    if (zeroCents) {
      var zeroMatcher = ("("+ separator +"[0]{0,"+ precision +"})"),
          zeroRegExp = new RegExp(zeroMatcher, "g");
      value = value.toString().replace(zeroRegExp, "");
    }
    var number = value.toString().replace(/[\D]/g, ""),
        clearDelimiter = new RegExp("^(0|\\"+ delimiter +")"),
        clearSeparator = new RegExp("(\\"+ separator +")$"),
		moneyPrecision = zeroCents ? 0 : precision,
        money = number.substr(0, number.length - moneyPrecision),
        masked = money.substr(0, money.length % 3),
        cents = new Array(precision + 1).join("0");
    money = money.substr(money.length % 3, money.length);
    for (var i = 0, len = money.length; i < len; i++) {
      if (i % 3 === 0) {
        masked += delimiter;
      }
      masked += money[i];
    }
    masked = masked.replace(clearDelimiter, "");
    masked = masked.length ? masked : "0";
    if (!zeroCents) {
      var beginCents = number.length - precision,
          centsValue = number.substr(beginCents, precision),
          centsLength = centsValue.length,
          centsSliced = (precision > centsLength) ? precision : centsLength;
      cents = (cents + centsValue).slice(-centsSliced);
    }
    var output = (unit + masked + separator + cents);
    output = output.replace(clearSeparator, "");
    return output;
};

function roundCurrencyDecimal(value) {
  value = +value;

  if (isNaN(value))
    return NaN;

  // Shift
  value = value.toString().split('e');
  value = Math.round(+(value[0] + 'e' + (value[1] ? (+value[1] + 2) : 2)));

  // Shift back
  value = value.toString().split('e');
  return (+(value[0] + 'e' + (value[1] ? (+value[1] - 2) : -2))).toFixed(2);
}

Handlebars.registerHelper('formatCurrency', function(country,amount) {
		amount = amount+"";
		if(amount.indexOf(".") != -1)
			amount = roundCurrencyDecimal(amount);
		return (country=="COM01") ?  "&pound;"+amount : "&euro;"+amount;
});

Handlebars.registerHelper('my3Text', function(prop, params) {

  if(params && (null != params.hash["param1"])){

	  if((undefined === prop)) return params.hash["key"];
	  var count = 0,key = prop[params.hash["key"]];
	
	  for(var param in params.hash) {
	
		if(param.indexOf("param") != -1){
			key = key.replace("\{"+count+"\}",params.hash[param]);
			count++;
		}
	  }
	  return new Handlebars.SafeString(key);
  }
  return (undefined === prop || null == params) ? params.hash["key"] : new Handlebars.SafeString(prop[params.hash["key"]]);
});

Handlebars.registerHelper('formatVoucher', function(voucherNumber) {
	  return maskToPattern(voucherNumber,"9999 9999 9999 9999");
});
Handlebars.registerHelper('formatUKMSISDN', function(topupmsisdn) {
	   if(null != topupmsisdn && topupmsisdn != "" && topupmsisdn.indexOf("44")==0 ){
			topupmsisdn = topupmsisdn.replace(/^(44)/,"0");
	   }
	  return maskToPattern(topupmsisdn,"99999 999 999");
});

Handlebars.registerHelper('for', function(from, to, incr, block) {
	var data;
	if (block.data) {
        data = Handlebars.createFrame(block.data);
    }
    var accum = '';
    for(var i = from; i < to; i += incr){
		data["forIdx"]=i;
        accum += block.fn(this,{data:data});
	}
    return accum;
});

 Handlebars.registerHelper('format', function (context, options) {
        var type = options.hash.type;
        switch (type) {
            case 'price':
                return 'R$ ' + context; //formatPrice ...
            case 'percent':
                return formatPercent(context, options);
            case 'floatdigit':
                return formatFloat(context, options);
            default :
                return;
        }
    });
    function formatPercent(context, options) {
        var fixed = options.hash.fixed || 2;
        return  (context * 100).toFixed(fixed) + '%';
    };
    function formatFloat(context, options) {        
        return  parseFloat(context).toFixed(options.hash.digits);
    };

 



Handlebars.registerHelper("x", function (expression, options) {
  var fn = function(){}, result;

  // in a try block in case the expression have invalid javascript
  try {
	if(options.hash && (null != options.hash)){
		for(var param in options.hash) {
			expression = expression.replace(new RegExp("@"+param,'g'),options.hash[param]);
		}
	}
		
    fn = Function.apply(
      this,
      [
        'window', // or add more '_this, window, a, b' you can add more params if you have references for them when you call fn(window, a, b, c);
        'return ' + expression + ';' // edit that if you know what you're doing
      ]
    );
  } catch (e) {
    console.warn('[warning] {{x ' + expression + '}} is invalid javascript', e);
  }

  // then let's execute this new function, and pass it window, like we promised
  // so you can actually use window in your expression
  // i.e expression ==> 'window.config.userLimit + 10 - 5 + 2 - user.count' //
  // or whatever
  try {
    // if you have created the function with more params
    // that would like fn(window, a, b, c)
    result = fn.bind(this)(window);
  } catch (e) {
    console.warn('[warning] {{x ' + expression + '}} runtime error', e);
  }
  // return the output of that result, or undefined if some error occured
  return result;
});

Handlebars.registerHelper("xif", function (expression, options) {
    return Handlebars.helpers["x"].apply(this, [expression, options]) ? options.fn(this) : options.inverse(this);
});

/**
 * HashListener
 * @fileOverview
 *    Cross browser hash change listener.
 *    Released under MIT license.
 * @version   1.1.0
 * @author    Victor Villaverde Laan
 */
var HashListener = function (win) {
	var checkHash = function (forceCall) {
			// check if hash has been changed
			if (win.location.hash == currentHash && !forceCall)
				return;
			// set new hash
			currentHash = win.location.hash;
			// call onchange function
			if (onHashChange)
				onHashChange(currentHash);
		},
		onHashChange = null,
		intervalDelay = 200,
		currentHash, intervalID;
	return {
		/**
		 * Start listening to hash changes
		 * @param {Function} [onChange] (Re)set callback
		 * @param {Boolean} [callNow=false] Immediately call onchange
		 * @param {Number} [delay=200] This option is only for browser that don't support onhashchange event
		 */
		start: function (onChange, callNow, delay) {
			if (onChange)
				onHashChange = onChange;
			if (delay)
				intervalDelay = delay;
			if ('onhashchange' in win && !/msie/i.test(navigator.userAgent)) {
				win.onhashchange = function () {
					checkHash();
				};
			} else {
			// For IE
				// set current hash
				currentHash = win.location.hash;
				if (intervalID)
					clearInterval(intervalID);
				// interval for checking hash change
				intervalID = setInterval(checkHash, intervalDelay);
			}

			if (callNow === true)
				checkHash(true);
		},
		stop: function () {
			clearInterval(intervalID);
			win.onhashchange = null;
		}
	};

}(window);