function createCookie(name,value,days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime()+(days*24*60*60*1000));
		var expires = "; expires="+date.toGMTString();
	}
	else var expires = "";
	document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
		var c = ca[i];
		while (c.charAt(0)==' ') c = c.substring(1,c.length);
		if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return null;
}

function eraseCookie(name) {
	createCookie(name,"",-1);
}

function bindLeftClickEvents(tagID,tagHorizontalPosition){
	$("#"+tagID+" .tag-image").bind("click",function(){
		if(!$("#"+tagID).hasClass("active")){	
			$("#"+tagID).addClass("active");
			$("#"+tagID).animate({left:tagHorizontalPosition},1000); 
		}		
	});
	$("#"+tagID+" .close-button").bind("click",function(){
		if($("#"+tagID).hasClass("active")){	
			$("#"+tagID).removeClass("active");
			$("#"+tagID).animate({left:'-223'},1000); 
		}		
	});
	
}

function bindClickEventsFade(tagID){
	$("#"+tagID+" .tag-image").bind("click",function(){
		if(!$("#"+tagID).hasClass("active")){	
			$("#"+tagID).addClass("active");
			$("#"+tagID).fadeIn('slow');
		}
	});
	$("#"+tagID+" .close-button").bind("click",function(){
		if($("#"+tagID).hasClass("active")){	
			$("#"+tagID).removeClass("active");
			$("#"+tagID).fadeOut('slow'); 
		}		
	});
}

function bindRightClickEvents(tagID,tagHorizontalPosition){
	$("#"+tagID+" .tag-image").bind("click",function(){
		if(!$("#"+tagID).hasClass("active")){	
			$("#"+tagID).addClass("active");
			$("#"+tagID).animate({right:tagHorizontalPosition},1000); 
		}		
	});
	$("#"+tagID+" .close-button").bind("click",function(){
		if($("#"+tagID).hasClass("active")){	
			$("#"+tagID).removeClass("active");
			$("#"+tagID).animate({right:'-223'},1000); 
		}		
	});
}

function bindImageHoverState(tagID,i,clear){	
	if($(".ie6").length > 0){		
		$("#"+tagID+" .close-button").hover(
			function(){
				$("#"+tagID+" .close-button .ie6-close-button").css('display','none');	
				$("#"+tagID+" .close-button .ie6-close-button-hover").css('display','inline');
			},
			function(){
				$("#"+tagID+" .close-button .ie6-close-button-hover").css('display','none');	
				$("#"+tagID+" .close-button .ie6-close-button").css('display','inline');				
			}
		);		
	} else {
		$("#"+tagID+" .close-button").bind("mouseenter",function(){
			$("#"+tagID+" .close-button .close-button-img").addClass("hide");	
			$("#"+tagID+" .close-button .close-button-hover-img").removeClass("hide");	
		});	
		$("#"+tagID+" .close-button").bind("mouseleave",function(){
			$("#"+tagID+" .close-button .close-button-hover-img").addClass("hide");
			$("#"+tagID+" .close-button .close-button-img").removeClass("hide");	
		});
	}
	
	if(clear){
		$("#"+tagID+" .container").bind("mouseenter",function(){			
			$("#"+tagID+" .container .no-hover").addClass("hide");	
			$("#"+tagID+" .container .hover").removeClass("hide");				
			clearTimeout(timeoutShow[i]);
			clearTimeout(timeoutHide[i]);		
		});
	} else {
		$("#"+tagID+" .container").bind("mouseenter",function(){			
			$("#"+tagID+" .container .no-hover").addClass("hide");	
			$("#"+tagID+" .container .hover").removeClass("hide");				
		});
	}	
		
	$("#"+tagID+" .container").bind("mouseleave",function(){
		$("#"+tagID+" .container .hover").addClass("hide");
		$("#"+tagID+" .container .no-hover").removeClass("hide");				
	});		
}


function autoAnimate(tagID,delayShow,delayHide,i){
	var d1 = parseInt(delayShow)*1000;
	var d2 = parseInt(delayHide)*1000;
	timeoutShow[i] = setTimeout(function(){
		$("#"+tagID+" .tag-image").click();
	},d1);
	timeoutHide[i] = setTimeout(function(){
		$("#"+tagID+" .close-button").click();
	},d2);
}

var timeoutShow = new Array();
var timeoutHide = new Array();

$(document).ready(function() {	
	if($(".ie6").length > 0){
		if(!($(".ie6-close-button")).length > 0){
			$(".close-button").append("<div class='ie6-close-button'></div>");
			$(".close-button .close-button-img").remove();
		}
		if(!($(".ie6-close-button-hover")).length > 0){
			$(".close-button").append("<div class='ie6-close-button-hover' style='display:none;'></div>");
			$(".close-button .close-button-hover-img").remove();
		}		
	}	
	var tagHorizontalPosition;
	var tagVerticalPosition;
	var tagLocation = "left";
	var tagMeasureFromCentre = "false";
	var tagAnimateHideLength = new Array();;
	var tagAnimateShowLength = new Array();;
	var tagAutoAnimate = new Array();
	var tagID;
	var tagIDArray = new Array();
	var tagIDArrayIndex = 0;
	var checkCookie = "false";
	var showTag = new Array();
	var animationType = "slide";
	
	
	$(".notification-tag").each(function(){
		if(!($(this).hasClass("moved"))){
			$(this).addClass("moved");
			
			tagID = $(this).attr("id");	
			
			showTag[tagIDArrayIndex] =  false;
			checkCookie = $(this).attr("data-checkCookie");
			if(checkCookie == "true"){
				if(readCookie("cookie_notification_"+tagID) == null){	
					showTag[tagIDArrayIndex] =  true;
					createCookie("cookie_notification_"+tagID,"true",365);
				}
			} else {
				showTag[tagIDArrayIndex] =  true;
			}			
			
			if(showTag[tagIDArrayIndex]){
				tagIDArray[tagIDArrayIndex] = tagID;			
				tagAnimateHideLength[tagIDArrayIndex] = parseInt($(this).attr("data-tagAnimateHideLength"));
				tagAnimateShowLength[tagIDArrayIndex] = parseInt($(this).attr("data-tagAnimateShowLength"));
				tagAutoAnimate[tagIDArrayIndex] = $(this).attr("data-tagAutoAnimate");				
				tagHorizontalPosition = parseInt($(this).attr("data-taghorizontalposition"));
				tagVerticalPosition = $(this).attr("data-tagverticalposition");	
				tagLocation = $(this).attr("data-taglocation");				
				tagMeasureFromCentre = $(this).attr("data-tagmeasurefromcentre");	
				animationType = $(this).attr("data-animationtype");	
						
				if(tagMeasureFromCentre == "false" && tagHorizontalPosition < 0){
					tagHorizontalPosition = 0;
				}						
				if(tagMeasureFromCentre == "false" && tagVerticalPosition < 0){
					tagVerticalPosition = 0;
				}
				
				$("#"+tagID).appendTo($("body"));
				
				if(animationType == "fade"){
					$(this).css({
						'display':'none',
						'top':function(){return parseInt(tagVerticalPosition);}
					});
						
					if(tagLocation == "left" && tagMeasureFromCentre == "false"){
						$(this).css({
							'left':parseInt(tagHorizontalPosition)
						});
						bindClickEventsFade(tagID,tagHorizontalPosition);
					} else if(tagLocation == "right" && tagMeasureFromCentre == "false"){
						$(this).css({
							'right':parseInt(tagHorizontalPosition)					
						});
						bindClickEventsFade(tagID,tagHorizontalPosition);
					} else if(tagLocation == "right" && tagMeasureFromCentre == "true"){
						var right = parseInt(tagHorizontalPosition) + ($(document).width()/2) -140;
						$(this).css({
							'right':right
						});
						bindClickEventsFade(tagID);
					} else if(tagLocation == "left" && tagMeasureFromCentre == "true"){
						var left = parseInt(tagHorizontalPosition) + ($(document).width()/2) -140;
						$(this).css({
							'left':left			
						});
						bindClickEventsFade(tagID);
					}
				} else {
					$(this).css({
							'display':'block',
							'top':parseInt(tagVerticalPosition)					
					});
					
					if(tagLocation == "left") {
						$(this).css({
							'left':'-223px'				
						});
							
						if (tagMeasureFromCentre == "false"){
							bindLeftClickEvents(tagID,tagHorizontalPosition);
						} else {
							var left = parseInt(tagHorizontalPosition) + ($(document).width()/2) - 140;
							bindLeftClickEvents(tagID,left);
						}
						
						
						
					} else if(tagLocation == "right"){
						$(this).css({
							'right':'-223px'				
						});
						
						if (tagMeasureFromCentre == "false"){
							bindRightClickEvents(tagID,tagHorizontalPosition);
						} else if (tagMeasureFromCentre == "true"){
							var left = parseInt(tagHorizontalPosition) + ($(document).width()/2) - 140;
							bindRightClickEvents(tagID,left);
						}
					}
				}	
				tagIDArrayIndex++;
			} else {
				$("#"+tagID).remove();
			}
		}		
	});
	
	//Animation
	for(var i = 0; i<tagIDArrayIndex; i++){	
		if(showTag[i]){
			var tagID = tagIDArray[i];
			if(tagAutoAnimate[i] == "true"){			
				var delayHide = tagAnimateHideLength[i];
				var delayShow = tagAnimateShowLength[i];	
				delayHide += delayShow;
				autoAnimate(tagID,delayShow,delayHide,i);
				bindImageHoverState(tagID,i,true);
			} else {
				if (animationType=="fade") {
					$("#"+tagID+" .tag-image").click();
				}
				bindImageHoverState(tagID,i,false);			
			}
		}
	}
	
	//Fix ie6
	if($(".ie6").length > 0){
		DD_belatedPNG.fix('.notification-tag');
		DD_belatedPNG.fix('.ie6-close-button');
		DD_belatedPNG.fix('.ie6-close-button-hover');
	}
	
});	