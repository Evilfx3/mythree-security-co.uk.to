var my3_rest_org='COM01';
var my3_rest_channel='Web';