 function showSecondMenu(listName) {
    if ($('#' + listName).hasClass('expanded')) {
      $('#' + listName).slideUp('slow');
      $('#' + listName).removeClass('expanded');
      $('#' + listName).siblings("div.expandButton").find('a').removeClass('showMinus');
    } else {
      $("div.expandButton a").removeClass('showMinus');
      $('ul.secondLevel').slideUp('fast');
      $('ul.secondLevel').removeClass('expanded');
      $('#' + listName).slideDown('slow');
      $('#' + listName).addClass('expanded');
      $('#' + listName).siblings("div.expandButton").find('a').addClass('showMinus');
    }
 }
 
if ($(".secondLevelItem.activePage").length > 0){
  $('.firstLevelItem').removeClass("activePage");
}

