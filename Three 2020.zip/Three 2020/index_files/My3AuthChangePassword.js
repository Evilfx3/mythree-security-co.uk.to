function ajaxCallback(targetUrl,inputData,authToken,callBack){
	$.ajax({
    dataType: "JSON",
	type: "POST",
	contentType: "application/x-www-form-urlencoded; charset=utf-8",
	url: targetUrl,
	data:inputData,
	beforeSend:	function(request){
		  request.setRequestHeader('X-H3G-ORG-ID',my3_rest_org);
		  request.setRequestHeader('X-Channel-Header',my3_rest_channel);
		  if(authToken!=null && authToken!=""){
		    request.setRequestHeader('X-Auth-Ticket-Header',authToken);
		 }
	},
	statusCode: {
	     401:function() { 
	    	  alert("401 - your session expired , Click Ok to relogin"); location.reload(true);
	    	  },
	     500:function(){
	    	var error=handlerError("ux.exception.general.error");
	    	return callBack($.parseJSON(error));  
	    	 },
	     404:function(){
	     	var error=handlerError("ux.exception.general.error");
	     	return callBack($.parseJSON(error));  
	     	 }
		  }
		 }).success( function(data){
			 return callBack(data);
		});
	 }

function changePasswordwithAuth(msisdn,passwd1,passwd2,callBack)
{	
	if(msisdn==null || msisdn==''){
		var error=handlerError("exception.msisdn.blank");
		return callBack($.parseJSON(error));
	}
	
	if(passwd1==null || passwd1==''){
		var error=handlerError("exception.password.blank");
		return callBack($.parseJSON(error));
	}
	
	if(passwd1.length<7){
		var error=handlerError("exception.password.short");
		return callBack($.parseJSON(error));
	}	
	
	if(passwd2==null || passwd2==''){
		var error=handlerError("exception.password.blank");
		return callBack($.parseJSON(error));
	}
	
	if(passwd2.length<7){
		var error=handlerError("exception.password.short");
		return callBack($.parseJSON(error));
	}	
	
	if(passwd1!=passwd2){
		var error=handlerError("exception.password.mismatch");
		return callBack($.parseJSON(error));
	}
	
//	if(!CheckPassword(passwd1)){
//	//alert("entering");
//		var error=handlerError("Your password must be at least 7 to 30 characters long and must contain at least one number and one letter and one special character");
//		return callBack($.parseJSON(error));
//	}
	var inputData={};
	inputData['msisdn']=msisdn;
	inputData['newPassword']=passwd1;
	
	ajaxCallback("/SceRestService/SSOUserRestService/rest/changePassword/doChange",inputData,null,function(data){
		return callBack(data);
	});
}

function getLocalisedMsisdn(msisdn)
{
	var msisdnLength = msisdn.length;
	var result = msisdn;
	if (msisdnLength == 12 && msisdn.substring(0, 2) == "44") {
		result = "0" + msisdn.substring(2);
	} else if (msisdnLength == 12 && msisdn.substring(0, 3) == "353") {
		result = "0" + msisdn.substring(3);
	}
	return result;
}

