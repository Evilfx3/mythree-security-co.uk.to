<footer>
<div class="footer clearboth wrapper">
<div class="primary-footer layout-3">
<div class="inner">
<div class="section-body">
<div class="content-a layout-level-1">
<div class="layout-level-2">
<h3>About us</h3>
<ul class="list-icons list-icons-links list-icons-small">
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Corporate website</a></li>
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Careers</a></li>
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Contact us</a></li>
</ul>
</div>
<div class="layout-level-2">
<h3>Our partners</h3>
<ul class="list-icons list-icons-links list-icons-small">
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Tesco.com</a></li>
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Media and investors</a></li>
</ul>
</div>
<div class="layout-level-2">
<h3>Security</h3>
<ul class="list-icons list-icons-links list-icons-small">
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Security and legal</a></li>
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Privacy and cookies</a></li>
<li><i class="icon icon-link-arrow icon-link-arrow-12px"></i><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#">Accessibility</a></li>
</ul>
</div>
</div>
</div>
<ul class="social-icons">
<li><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#"><i class="icon icon-twitter"></i><span class="screen-reader-only">Twitter</span></a></li>
<li><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#"><i class="icon icon-youtube"></i><span class="screen-reader-only">YouTube</span></a></li>
<li><a data-ens-analytics-text="footer link :#" data-ens-attached="true" href="#"><i class=
"icon icon-community-social-link"></i><span class="screen-reader-only">Your Community</span></a></li>
</ul>
</div>
</div>
<nav class="sitemap layout-3">
<div class="inner">
<h2 class="js-accordion hide-on-extra-small" data-accordion-content="#sitemap-content"><a class="js-accordion-trigger" data-ens-analytics-text="footer link :#sitemap-content" data-ens-attached="true"
href="#"><span class="js-title">Sitemap</span> <i class="icon icon-arrow-down-light"></i></a></h2>
<p class="copyright">Copyright &copy; 2015 Tesco Personal Finance plc</p>
</div>
</nav>
</div>
</footer>