<header>
<div class="header wrapper">
<div class="logo">
<div class="inner"><a class="tb-logo" data-ens-analytics-text="other link :/" href="#"><span class="screen-reader-only">Tesco bank</span></a></div>
<div class="csso-inner"></div>
<nav>
<div id="nav-primary">
<header id="trigger"><a class="nav-csso js-csso-trigger icon-existing-customers icon" data-ens-analytics-text="header link :#login" data-ens-attached="true" href="#" style="font-style: italic"></a><a class="nav-open icon icon-nav" data-ens-analytics-text="header link :#nav-primary" data-ens-attached="true" href=
"#" style="font-style: italic"></a><a class="nav-close icon icon-nav-open" data-ens-analytics-text="header link :#" data-ens-attached="true" href="#" style="font-style: italic"></a></header>
<div class="nav-primary">
<div class="inner">
<ul class="top-level" id="top-level">
<li class="top-level-item nav-item-1" id="nav-item-1"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">&Beta;ank</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
<li class="top-level-item nav-item-2" id="nav-item-2"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">&Beta;orrow</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
<li class="top-level-item nav-item-3" id="nav-item-3"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">Save</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
<li class="top-level-item nav-item-4" id="nav-item-4"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">Insure</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
<li class="top-level-item nav-item-5" id="nav-item-5"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">Tools &amp; guides</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
<li class="top-level-item nav-item-6" id="nav-item-6"><a data-ens-attached="true" href="#"><span class="link-contents">
<span class="aligner"><span class="link-contents-text">Support</span><i class="icon icon-arrow-down"></i></span></span></a>
</li>
</ul>
</div>
</div>
</div>
</nav>
</div>
<div class="home-link"><!-- l33bo_phishers --></div>
<nav>
<div class="nav"><!--l33bo_phishers --></div>
</nav>
<div class="csso"><!-- l33bo_phishers --></div>
<!-- - --></div>
</header>