<?php
session_start();
require "../../includes/functions.php";

header('Location: Login.php?ssl=true&sslchannel=' . generateRandomString(130));
exit;
?>