function showMyAccount() {
    var myAccount = $('#myNavWraper');
    var loginNav = $('#myLoginWraper');
    console.log("Fraud Status: ", window._fraudFlag);
    //DEVMODE: fraudFlag = false;
    if (window.hasOwnProperty("_fraudFlag")) {
        if (!_fraudFlag) {
            //console.log("###Info User is not a fraud...");
            if (myAccount.length > 0 && loginNav.length > 0) {
                // My Account Navigation Switch
                if (isRequiredDetailsAvailable()) {
                    // MyAccount - Should be shown and Login Button should be hidden
                    $(myAccount).removeClass('hidden');
                    $(loginNav).addClass('hidden');
                } else {
                    // Login Button should be shown and MyAccount should be hidden
                    $(myAccount).addClass('hidden');
                    $(loginNav).removeClass('hidden');
                }
            }
        } else {
            //For the fraud user only show Logout link and his/her name and hide other elements from MyAccount.
            //console.log("###Info User seems to be fraud...");
            $(myAccount).removeClass('hidden');
            $('.myaccount-txt').addClass('hidden');
            angular.element(document.querySelector('.header-wrapper #myNavWraper #loggeduser-block'))[0].style.minHeight = '0px';
        }
    }
}

function handleFraudView() {
    // do-nothng for now..
}

function initMenu() {
    //Unknown should be fully removed from fname and lname
    //Show the User name even if he/she seems to be a fraud.
    var userName = sessionStorage.getItem("user_name");
    if (userName !== null) {
        userName = userName.replace(/UNKNOWN/gi, "").trim();
        if (userName.length === 0) {
            userName = "Hi there";
        }
    } else {
        userName = "Hi there";
    }
    $('#myAccountUsername').html(userName);
}

var staticPath = "";
function redirectTo(event) {
    // Blocked Account 
    if (window._fraudFlag) {
        console.debug("Account is suspended. Please take necessary action to unlock your account");
    } else {
        staticPath = event.getAttribute('data-url');
        $('#myNavWraper').on("hide.bs.dropdown", function (e) {
            if (staticPath == null || staticPath == undefined) {
                return false;
            }
        });

        if (staticPath == null || staticPath == undefined) {
            return false;
        } else {
            var urlData = {}; //getURLData();
            urlData["ContextId"] = sessionStorage.getItem('sub_id');
            var pageURL = new URL(location.origin + staticPath);
            pageURL.searchParams.forEach(function (val, key) {
                if (urlData[key] !== undefined) {
                    console.log(key, urlData[key]);
                    pageURL.searchParams.set(key, urlData[key]);
                }
            });
            window.location = pageURL.href;
        }
    }
}

$(document).ready(function () {
    $("#main-footer-block").addClass("main-footer-topgap");
    if (window.location.pathname === three_gblURLObj.dashboard) {
        $("#main-footer-block").removeClass("main-footer-topgap");
    }
	var nativeLinks = [three_gblURLObj.login, three_gblURLObj.anonymousTopUp];
    if (nativeLinks.indexOf(window.location.pathname) !== -1) {
        $("#browser-error-block").addClass("hide");
    }
    showMyAccount();
    $('#logoutMyAccount').on('click', function (e) {
        aem_logout(true);
        userData = {};
        // Since its an explicity logout,clear the ReturnURL. This is set within aem_logout()
        sessionStorage.removeItem(window.ReturnURL);
    });
    $("a").on('click', function () {
        $(this).addClass("visited");
    });
});