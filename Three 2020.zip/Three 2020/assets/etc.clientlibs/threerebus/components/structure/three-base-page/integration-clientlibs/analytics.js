/**
 * This file contains the dataLayer Implementation for Three
 */
console.group("Analytics")
window.digitalData = {};
function DataLayer() {};
/**
 * Method responsible for updating page object within datalayer
 */
DataLayer.prototype._page = function () {
    this._page = { };
    var pageURL = new URL(window.location.href);

    const pathName = window.location.pathname.toLowerCase();
    const pageName = "pageName";
    const channel = "channel";
    const subSection_1 = "subSection1";
    const subSection_2 = "subSection2";
    const subSection_3 = "subSection3";
    const userType = "userType";
    const portalType = "portalType";
    const portalTypeValue = "web";
    const typeOfPage = "typeOfPage";
    const customerId = "customerId";
    const domain = "Three";
    const colonString = ":";
    let   pNameValue = "";
    let   subSection_1Value = "";
    let   subSection_2Value = "";
    let   typeOfPageValue = "";

    /**
     *Function responsible for generating pageName for DataLayer  
     */
    function getPageName() {
        let pageNameValue = "";
        var pathName = window.location.pathname;
        if (pathName !== "/") {
            if (!(pathName.indexOf("/content/three-rebus") > 0)) {
                let urlSplitArray = pathName.split("/");
                for (let i = 1; i < urlSplitArray.length; i++) {
                    if (i === 1) {
                        pageNameValue = domain + colonString + urlSplitArray[i];
                    } else {
                        pageNameValue += colonString + urlSplitArray[i];
                    }
                }
            } else {
                console.error("Vanity Path is not defined");
            }
        } else {
            pageNameValue = domain + colonString + "home";
        }
        return pageNameValue;
    }
    /**
     * Function responsible for generating subSection1 for DataLayer 
     * @param {pageName} pNameValue 
     */
    function getSubSection1(pNameValue) {
        let subSection_1Val;
        if (pNameValue !== "") {
            let pNameSplitArray = pNameValue.split(colonString);
            subSection_1Val = pNameSplitArray[0] + colonString + pNameSplitArray[1];
        } else {
            subSection_1Val = "";
        }
        return subSection_1Val;
    }
    /**
     * Function responsible for generating subSection2 for DataLayer
     * @param {pageName} pNameValue 
     */
    function getSubSection2(pNameValue) {
        let subSection_2Val = "";
        if (pNameValue !== "") {
            let pNameSplitArray = pNameValue.split(colonString);
            for (let i = 0; i < 3; i++) {
                if (pNameSplitArray.length > 2) {
                    if (i < 2) {
                        subSection_2Val += pNameSplitArray[i] + colonString;
                    } else {
                        subSection_2Val += pNameSplitArray[i];
                    }
                } else {
                    subSection_2Val = pNameSplitArray[0] + colonString + pNameSplitArray[1];
                }

            }
        } else {
            subSection_2Val = "";
        }
        return subSection_2Val;
    }
    /**
     * Function responsible for generating typeOfPage for DataLayer
     * @param {pageName} pNameValue 
     */
    function getTypeOfPage(pNameValue) {
        let pNameSplitArray = pNameValue.split(colonString);
        return pNameSplitArray[1];
    }
    
    pNameValue = getPageName();
    console.info("pNameValue" + pNameValue);
    subSection_1Value = getSubSection1(pNameValue);
    subSection_2Value = getSubSection2(pNameValue);
    typeOfPageValue = getTypeOfPage(pNameValue);

    this._page[pageName] = pNameValue;
    this._page[channel] = domain;
    this._page[portalType] = portalTypeValue;
    this._page[subSection_1] = subSection_1Value;
    this._page[subSection_2] = subSection_2Value;
    this._page[subSection_3] = pNameValue;
    this._page[typeOfPage] = typeOfPageValue;

    var __loginSuccess = sessionStorage.getItem("__loginSuccess");
    if (__loginSuccess !== null && __loginSuccess !== '...') {
        this._page["loginSuccess"] = __loginSuccess;
        sessionStorage.setItem("__loginSuccess", "...");
    }

    this._page[userType] = window.isLoggedIn() ? 'logged-in' : 'non-logged-in';
    
    if (window.isLoggedIn()) {
        this._page["customerID"] = sessionStorage.getItem("cid");
    }
    return this._page;
};
/**
 * 
 * Method responsible for updating event object within datalayer
 */
DataLayer.prototype._event = function () {
    this._event = {
    };
    return this._event;
};
/**
 * 
 * Function responsible for updating/creating datalayer objects 
 */
function updateDataLayer(objName, key, value) {
    if (objName && key && value) {
        if (digitalData.hasOwnProperty(objName)) {
            let tmpObj = digitalData[objName];
            tmpObj[key] = value;
        } else {
            digitalData[objName] = {};
            let tempObj = digitalData[objName];
            tempObj[key] = value;
            console.info("New Object Added");
            console.log(digitalData[objName]);
        }
    } else {
        console.error("Pass appropriate parameters[objName;key;value]");
    }
};

let dataLayer = new DataLayer();
digitalData.page = dataLayer._page();
digitalData.dtmEvent = dataLayer._event();
console.groupEnd();
