window.loadExternalOS = true;
window.three_gblChannel = 1;
window.three_clearCookie = function (name) {
    document.cookie = encodeURIComponent(name) + "=deleted;  Path=/; expires=" + new Date(0).toUTCString();
}
window.three_Domain = window.location.origin;

window.three_gblURLObj = {
    "topupLanding": "/account/top-up",
    "topupByBundle": "/account/top-up/bundle",
    "cashCredit": "/account/top-up/credit",
    "differentNumber": "/account/top-up/different-number",
    "topup_different_number": "/account/top-up/different-number",

    "browsePaygBundles": "/account/top-up/browse-bundles",
    "browse_payg_bundles": "/account/top-up/browse-bundles",
    "buyAgainBundle": "/account/top-up/buy-again-bundle",
    "buyAgainCredit": "/account/top-up/buy-again-credit",
    "buyAgainAddon": "/my3account/buy-more-addons",

    "manageAutoTopup": "/account/top-up/view-auto-top-up",
    "view_auto_topup": "/account/top-up/view-auto-top-up",
    "autoTopUp": "/account/top-up/auto-top-up",
    "autoTopUpByBundle": "/account/top-up/auto-top-up/bundle",
    "cancelAutoTopupPayment": "/account/top-up/auto-top-up/cancel",
    "topupByBundleAnon": "/account/top-up/topup-by-bundle-anon",
    "redeemVoucher": "/account/top-up/voucher",
    "anonymousTopUp": "/account/anonymous-top-up",

    // -- 22, 23
    "editAutoTopupBalance": "/account/top-up/auto-top-up/edit-auto-topup-balance",
    "editAutoTopupPayment": "/account/top-up/auto-top-up/edit-auto-topup-payment",

    // From Topup Landing Page
    "topup_landing_page": "/account/top-up",
    "browse_payg_bundles": "/account/top-up/browse-bundles", //working
    "topup_cash_credit": "/account/top-up/credit", //working
    "redeem_voucher": "/account/top-up/voucher",
    "buy_again_bundle": "/account/top-up/buy-again-bundle",
    "buy_again_credit": "/account/top-up/buy-again-credit",
    "auto_topup": "/account/top-up/auto-top-up", //working
    "topup_by_bundle": "/account/top-up/bundle", //working

    "ReturnToDashboard": "/account",

    // Login
    "login": "/account/login",
    "idkNumber": "/account/login/find-my-number",
    "resetPassword": "/account/login/reset-password",
    // Your Details
    "changePersonalDetails": "/account/your-details",
    "changeAddress": "/account/your-details/address",
    "changeAlternateNumber": "/account/your-details/alternate-number",
    "changeDOB": "/account/your-details/date-of-birth",
    "changeEmail": "/account/your-details/email",
    "changeName": "/account/your-details/name",
    "changePassword": "/account/your-details/change-password",
    //"changeTitle":"/my3account/change-title-and-name",
    "changeNumber": "/account/account-settings/change-number",
    "marketingPrefDataConsents": "/account/your-details/marketing-preferences",

    // Add-ons
    "browseAddon": "/account/add-ons/browse",
    "buyAddon": "/account/add-ons/buy",
    "viewAddon": "/account/add-ons/view",
    "manageAddon": "/account/add-ons/manage",
    "recurrenceActivationSettings": "/account/activation-recurrence",
    "cancelRecurringAddon": "/account/add-ons/cancel-recurrence",
    "buyMoreAddons": "/account/add-ons/buy-more",
    "addonConfirmation": "/account/add-ons/buy-more/confirm",

    // Case Management
    "caseDetail": "/account/help/issues/case-detail",
    "closeCase": "/account/help/issues/close",
    "reopenCase": "/account/help/issues/reopen",
    "myIssues": "/account/help/issues",
    "otherCloseReason": "/account/help/issues/reason",
    // Dashboard
    "dashboard": "/account",

    // Manage Lost or Stolen
    "manageLostAndStolen": "/account/help/lost-or-stolen",
    "barDevice": "/account/help/lost-or-stolen/bar-device",
    "suspendSIM": "/account/help/lost-or-stolen/suspend-sim",
    "unbarDevice": "/account/help/lost-or-stolen/unbar-device",
    "unsuspendSIM": "/account/help/lost-or-stolen/unsuspend-sim",
    // Replacement SIM
    "orderAndSIMReplacement": "/account/help/replace-sim",
    "activateReplacementSIM": "/account/help/replacement-sim/activate",
    // Adult Filter
    "adultFilterOn": "/account/account-settings/adult-filter-on",
    "adultFilterOff": "/account/account-settings/adult-filter-off",
    // Unlock SIM
    "pukUnlock": "/account/help/unlock-sim",
    // Port-In 
    "requestPortIn": "/account/help/switch-to-three",
    "viewPortIn": "/account/help/switch-to-three",
    // --
    "cancelPortIn": "/account/help/switch-to-three/cancel-port-in",
    "changePortInDate": "/account/help/switch-to-three/date-selection",
    "amendPortIn": "/account/help/switch-to-three/date-selection",

    // Port-Out 
    "portOut": "/account/help/switch-from-three",

    // Manage Payment
    "manageWallet": "/account/manage-cards",
    "addNewCard": "/account/manage-cards/add",
    "deleteCard": "/account/manage-cards/remove",
    "setDefaultCard": "/account/manage-cards/set-default",

    // Fraud Management - Suspicious Activity
    "fraudFlag": "/account/help/suspicious-activity/upload",
    "reportFraud": "/account/help/suspicious-activity",

    // View Services
    "viewServices": "/account/account-settings/manage-services",

    // Callback
    "paymentURL": window.three_Domain + "/bin/payment-handler",

    // Error page
    "error": "/content/three-rebus/error/error.html",
    "errorScreen": "/account/generic-error",
    "sessionTimeout": "/content/three-rebus/error/error.html",
    //View Charges
    "viewCharges": "/account/charges",
    "viewMyCharges": "/account/charges/view",
    //RebusLogin:
    "rebusLogin": "/account/three-login",
	
	 //Maintanence Release:
    "resendEmail":"/account/login/resend-email",
    "emailVerificationStatus":"/account/login/email-status",
    "pendingEmailVerification":"/account/login/verify-email"
	
};