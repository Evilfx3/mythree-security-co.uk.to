$( document ).ready(function() {

    function createCookie(name,value,days,path) {
        if (days) {
            var date = new Date();
            date.setTime(date.getTime()+(days*24*60*60*1000));
            var expires = "; expires="+date.toGMTString();
        }
        else var expires = "";
        document.cookie = name+"="+value+expires+"; path="+path;
    }
    function readCookie(name) {
        var cookieName = name + "=";
        var cookies = document.cookie.split(';');
        for(var i=0;i < cookies.length;i++) {
            var c = cookies[i];
            while (c.charAt(0)==' ') c = c.substring(1,c.length);
            if (c.indexOf(cookieName) == 0) return c.substring(cookieName.length,c.length);
        }
        return null;
    }
    var cookieMessage = document.getElementById('cookie-message');
    if (cookieMessage == null) {
        return;
    }
    var cookie = readCookie('cmsg');
    if (cookie != null && cookie == 'yes') {
        $("#cookie-message").addClass("hidden");
       // cookieMessage.style.display = 'none';

    } else {
         $("#cookie-message").removeClass("hidden");
       // cookieMessage.style.display = 'block';
    }
    var cookieExpiry = 30;
    
    var cookiePath = "/";
    
    $("#cookiebtn").on("click", function(){ 
    	createCookie('cmsg','yes',cookieExpiry,cookiePath);
         //cookieMessage.style.display = 'none';
		 $("#cookie-message").addClass("hidden");
	});
    });
