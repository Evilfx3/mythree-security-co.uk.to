var doRedirect = function(domain) {
	domain = domain.replace("three.co.uk", "three.ie");
	window.location.href = domain;
	document.close();
}

if (cDomain.indexOf('three.ie') >= 0) {
	var myQueueClient = new queueClient(companyName, queueitEventName, timeout, displayLanguage, {layoutName: lName, cookieDomain: cDomain, host: pHost, redirector: doRedirect});
}
else {
	var myQueueClient = new queueClient(companyName, queueitEventName, timeout, displayLanguage, {layoutName: lName, cookieDomain: cDomain, host: pHost});
}
