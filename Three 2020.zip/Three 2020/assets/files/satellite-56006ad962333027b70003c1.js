_satellite.pushAsyncScript(function(event, target, $variables){
  //Detects if iframes with a source of youtube is visible on page

if($('iframe[src*="youtube"]').length > 0){

  var tag = document.createElement('script');
  tag.src = "https://www.youtube.com/iframe_api";
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

}else{
  // Does not run youtube API 
}

/*
window.onYouTubeIframeAPIReady = function(){
   // setTimeout(XT.yt.onYouTubeIframeAPIReady,500);
  console.log("youTube IFrame API Ready now.");
}
*/

//  function onYouTubeIframeAPIReady() {
window.onYouTubeIframeAPIReady = function() {
    //Loops through number of youtube iframes

    $('iframe[src*="youtube"]').each(function(i){

      var ytPlayerID = "ytPlayerID" + i;
      var ytUrl = this.src;
      this.id = ytPlayerID; // Adds ID to the iframe

      if(/^(?!.*enablejsapi).*$/.test(ytUrl)){
				
        var queryQual = "?";
        if (ytUrl.indexOf("?") > 0)
        {
          queryQual = "&";
        }
        this.src = ytUrl + queryQual + 'enablejsapi=1'; //Adds enablejsapi=1 at the end of URL in order to work with API

      }

      ytPlayerID = new YT.Player(ytPlayerID, {
        events: {
        'onStateChange': onPlayerStateChange
        }
      });

    });

  }

  function onPlayerStateChange(event) {

      if (event.data == YT.PlayerState.PLAYING) {
         // var url = event.target.getVideoUrl();
         // var match = url.match(/[?&]v=([^&]+)/); // Gets Id from U
        //  var videoId = match[1];
		  var videoTitle = event.target.getVideoData().title;
		 // var bytesLoaded = event.target.B.videoBytesLoaded; //DEPRECATED - A value of 0 means the video is being played from the start
		  var timePlayed = event.target.getCurrentTime();
      if (timePlayed <= 3) {
			trackEvent(videoTitle);
		  }
      }
  }

  //Search info collected
  function trackEvent(videoId){

      s.linkTrackVars='eVar7,eVar9';
      s.eVar7='youtube-starts';
      s.eVar9='youtube-starts:[' + videoId + ']';
      s.tl(this,'o','youtube-starts',null);

  }
});
