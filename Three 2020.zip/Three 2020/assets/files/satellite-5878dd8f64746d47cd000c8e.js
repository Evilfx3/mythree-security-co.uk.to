_satellite.pushAsyncScript(function(event, target, $variables){
  var meta = document.createElement('meta');
meta.name = "apple-itunes-app";
meta.content = "app-id=393530266, affiliate-data=ct=my3-smart-banner&pt=421745";
document.head.appendChild(meta);
});
