_satellite.pushAsyncScript(function(event, target, $variables){
  /*
    DTM Campaign: Faraday - Mobile Navigation Tracking

    Summary:
    Tracking mobile menu opening & closing, interaction with navigation links.
*/

// Header links.
$('#home-and-menu a[href]').each(function(link) {
  $(this).on('click', function() {
    // Ensure the mobile breakpoint is active.
    if($('html').hasClass('phone')){
      var link = this;
      (s.linkTrackVars = ''),
        (s.eVar29 = 'mobile_navigation17:Header:' + headerLinkName(this));
      s.tl(this, 'o', 'mobile_navigation17', null);
    }
  });
});

function headerLinkName(link) {
  switch (link.pathname) {
    case '/My3Account':
      return 'My3';
      break;
    case '/':
      return 'Home';
      break;
    default:
      break;
  }
}

function isOpen() {
  if ($('body').hasClass('show-menu')) {
    return true;
  }
  return false;
}

// Opening and closing of the burger menu.
$('button.icon-menu').on('click', function() {
    (s.linkTrackVars = ''),
    (s.eVar29 = 'mobile_navigation17:' + 'open'),
    (s.eVar30 = window.location.href),
    s.tl(this, 'o', 'mobile_navigation17', null);
});

$('button.menu-close-icon, .page-overlay').on('click', function() {
  // Reset selection in case the menu is opened again.
  (s.linkTrackVars = ''),
    (s.eVar29 = 'mobile_navigation17:' + 'close'),
    s.tl(this, 'o', 'mobile_navigation17', null);
});

// Interaction on each link that goes to a page and be able to distinguish which link is being clicked.
$('#nav-and-search a[href]').each(function(link) {
  $(this).on('click', function() {
    if (isOpen()) {
      var link        = this,
      firstLevel  = $(this).parent().closest('ul.depth-2').siblings('a').text().trim() + ':';
      console.log('nav17: ' + 'mobile_navigation17:' + firstLevel + $(link).text().trim());
      (s.linkTrackVars = ''), (s.eVar29 = 'mobile_navigation17:' + firstLevel + $(link).text().trim());
      s.tl(this, 'o', 'mobile_navigation17', null);
    }
  });
});
});
