_satellite.pushAsyncScript(function(event, target, $variables){
  //Detects if My3 login iFrame loads

var iframeloaded=document.getElementById("loginIframe");
if(iframeloaded){
  iframeloaded.addEventListener('load', function() {
    //Call tracking function
    trackEvent('Loaded')
  });
} else {
  //Call tracking function
  trackEvent('NOT_Loaded')  
}

//track loading of iFrame
function trackEvent(trackiFrame){

  s.linkTrackVars='eVar8';
  s.eVar8='My3_login_iFrame:[' + trackiFrame + ']';
  s.tl(this,'o','My3_login_diagnostic_check',null);

}
});
