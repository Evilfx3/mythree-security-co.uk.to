var my3_rest_org='COM01';
var my3_rest_channel='Web';


//WP3
var registerEmail = "/mylogin/SSOEmail?action=doregister";
var validateEmail = "/mylogin/SSOEmail?action=emailvalidate";
var validationLinkSent = "/mylogin/SSOEmail?action=emailvalidatelink";
var editEmailAddress = "/mylogin/SSOEmail?action=emailedit";
var notValidatedAfter24Hrs = "/mylogin/SSOEmail?action=emailnotvalidatedafter24hrs";
var notValidatedBefore24Hrs = "/mylogin/SSOEmail?action=emailnotvalidatedbefore24hrs";
var restHostURL = "https://www.three.co.uk";


var isAvailable;
var isValidated;
var skipLimit;
var msisdn;
var validationLinkValid;
var validationLinkSent;
var threeOptIn;

sessionStorage.setItem("emailFlag", true);

function printLog(logValue){
	  try{
	  console.log(logValue);
	  }catch(err) {
	  }
}

function ajaxify(restUrl,clientDataType,serverDataType,clientData,requestType,successCallBack,errorCallBack){
		
		$.ajax({
			url: restHostURL+"/"+restUrl,
			contentType:clientDataType,
			data:clientData,
			beforeSend:function(jqXHR){
				jqXHR.setRequestHeader('X-H3G-ORG-ID',my3_rest_org);
				jqXHR.setRequestHeader('X-Channel-Header',my3_rest_channel);
			},
			dataType:serverDataType,
			type:requestType,
			success:successCallBack,			
			error:function(jqXHR, textStatus,exception){
				console.log("exception in calling ajax"+exception);
				var reqStatus = "";
				if (jqXHR.status === 0) {
					reqStatus = 'Not connected to the Network.Please check connection and try again.';
				} else if (jqXHR.status == 404) {
					reqStatus = 'Requested page not found. [404]';
				} else if (jqXHR.status == 500) {
					reqStatus = 'Server Problem.Please contact Customer Care';
				} else if (exception === 'parsererror') {
					reqStatus = 'Requested JSON parse failed.';
				} else if (exception === 'timeout') {
					reqStatus = 'Time out error.';
				} else if (exception === 'abort') {
					reqStatus = 'Ajax Request aborted.';
				} else {
					reqStatus =  'Uncaught Error.\n' + jqXHR.responseText;
				}
				console.log("Common Error Is"+reqStatus);
				return errorCallBack();
			}
		});
}


function ajaxifyNoLogin(restUrl,clientDataType,serverDataType,clientData,requestType,token,successCallBack,errorCallBack){
	
	$.ajax({
		url: restHostURL+"/"+restUrl,
		contentType:clientDataType,
		data:clientData,
		beforeSend:function(jqXHR){
			jqXHR.setRequestHeader('X-H3G-ORG-ID',my3_rest_org);
			jqXHR.setRequestHeader('X-Channel-Header',my3_rest_channel);
			jqXHR.setRequestHeader('X-Auth-Ticket-Header',token);
		},
		dataType:serverDataType,
		type:requestType,
		success:successCallBack,			
		error:function(jqXHR, textStatus,exception){
			console.log("exception in calling ajax"+exception);
			var reqStatus = "";
			if (jqXHR.status === 0) {
				reqStatus = 'Not connected to the Network.Please check connection and try again.';
			} else if (jqXHR.status == 404) {
				reqStatus = 'Requested page not found. [404]';
			} else if (jqXHR.status == 500) {
				reqStatus = 'Server Problem.Please contact Customer Care';
			} else if (exception === 'parsererror') {
				reqStatus = 'Requested JSON parse failed.';
			} else if (exception === 'timeout') {
				reqStatus = 'Time out error.';
			} else if (exception === 'abort') {
				reqStatus = 'Ajax Request aborted.';
			} else {
				reqStatus =  'Uncaught Error.\n' + jqXHR.responseText;
			}
			console.log("Common Error Is"+reqStatus);
			return errorCallBack();
		}
	});
}

function getContent(pageUrl,callBack){
	$.ajax({
    dataType: "HTML",
	type: "GET",
	contentType: "application/html; charset=utf-8",
	url: pageUrl,
	success: function(data) {        
		 return callBack(data);		 
       }, 
	error: function(){
		printLog("getContent(): Error getting content");
	}
	});
 }

function getCopy(portlet,copyUrl, callBack){
	$.ajax({
   	dataType: "JSON",
	type: "GET",
	contentType: "application/JSON",
	url: copyUrl,
	data: {"portlet": portlet},
	beforeSend:	function(request){
		  request.setRequestHeader('X-H3G-ORG-ID',my3_rest_org);
		  request.setRequestHeader('X-Channel-Header',my3_rest_channel);
	},
	success: function(data) {        
		 return callBack(data);		 
	}
	});
 }
 
function showListErrors(errContainer,errArr){
	$("#"+errContainer).show();
	$("#"+errContainer+" ul").html('');
	$.each(errArr, function( index, value ) {
		$("#"+errContainer+" ul").append("<li>"+value+"</li>");
	});
	window.parent.postMessage (document.body.scrollHeight,"*");
}

function resetListErrors(errContainer){
	$("#"+errContainer).hide();
	$("#"+errContainer+" ul").html('');
}


function checkEmail(msisdn,callBack){
		var inputData={};
		inputData['msisdn']=msisdn;
		ajaxify("SceRestService/My3CommonRestService/rest/msisdn/validate","application/json; charset=utf-8","json",inputData,"GET",function(data){
			if (data.statusCode == 0) {
				ajaxifyNoLogin("/SceRestService/SSOUserRestService/rest/checkEmailWithoutLogin","application/x-www-form-urlencoded; charset=utf-8","json",inputData,"POST",data.authCode,function(response){
					callBack(response);	
				},function(){});
			
			} else{ 
				console.log("else part ");
			}
		},function(){});
}
	
function captureEmail(msisdn,email,threeOptIn,thirdPartyOptIn,skipLimit,callBack){
	var inputData={};
	inputData['msisdn']=msisdn;
	inputData['email']=email;
	inputData['threeOptIn']=threeOptIn;
	inputData['thirdPartyOptIn']=thirdPartyOptIn;
	inputData['scenrio']="ssoLogin";
	inputData['skipLimit']=skipLimit;

	ajaxify("SceRestService/My3CommonRestService/rest/msisdn/validate","application/json; charset=utf-8","json",inputData,"GET",function(data){
		if (data.statusCode == 0) { 
			ajaxifyNoLogin("/SceRestService/SSOUserRestService/rest/captureEmailWithoutLogin","application/x-www-form-urlencoded; charset=utf-8","json",inputData,"POST",data.authCode,function(response){			
				callBack(response);
			},function(){});
		}
	},function(){});
}

function resendValidateEmail(msisdn,threeOptIn,callBack){		
		var inputData={};
		inputData['msisdn']=msisdn;
		inputData['scenario']="ssoLogin";
		inputData['threeOptIn']=threeOptIn;
	    ajaxify("SceRestService/My3CommonRestService/rest/msisdn/validate","application/json; charset=utf-8","json",inputData,"GET",function(data){
			if (data.statusCode == 0) {
				ajaxifyNoLogin("/SceRestService/SSOUserRestService/rest/resendEmail/withoutlogin","application/x-www-form-urlencoded; charset=utf-8","json",inputData,"POST",data.authCode,function(response){		
					callBack(response);
				},function(){});
			}
		},function(){});	
}

function updateSkipLimit(msisdn,callBack){		
	var inputData={};
	inputData['msisdn']=msisdn;
	inputData['scenario']="ssoLogin";

    ajaxify("SceRestService/My3CommonRestService/rest/msisdn/validate","application/json; charset=utf-8","json",inputData,"GET",function(data){
		if (data.statusCode == 0) {
			ajaxifyNoLogin("/SceRestService/SSOUserRestService/rest/updateSkipLimit","application/x-www-form-urlencoded; charset=utf-8","json",inputData,"POST",data.authCode,function(response){			
				callBack(response);
			},function(){});
		}
	},function(){});	
}

	
	