_satellite.pushAsyncScript(function(event, target, $variables){
  var body = document.getElementsByTagName('body')[0];
var element = document.createElement('script');
element.src = 'https://www.dwin1.com/10210.js';
element.setAttribute('defer', 'defer');
element.setAttribute('type', 'text/javascript');
body.append(element);
});
