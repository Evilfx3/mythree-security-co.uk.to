/*
 * validate.js 1.4
 * Copyright (c) 2011 - 2014 Rick Harrison, http://rickharrison.me
 * validate.js is open sourced under the MIT license.
 * Portions of validate.js are inspired by CodeIgniter.
 * http://rickharrison.github.com/validate.js
 */

(function(window, document, undefined) {
    /*
     * If you would like an application-wide config, change these defaults.
     * Otherwise, use the setMessage() function to configure form specific messages.
     */

    var defaults = {
        messages: {
            required: 'The %s field is required.',
            matches: 'The %s field does not match the %s field.',
            "default": 'The %s field is still set to default, please change.',
            valid_email: 'The %s field must contain a valid email address.',
            valid_emails: 'The %s field must contain all valid email addresses.',
            min_length: 'The %s field must be at least %s characters in length.',
            max_length: 'The %s field must not exceed %s characters in length.',
            exact_length: 'The %s field must be exactly %s characters in length.',
            greater_than: 'The %s field must contain a number greater than %s.',
            less_than: 'The %s field must contain a number less than %s.',
            alpha: 'The %s field must only contain alphabetical characters.',
            alpha_numeric: 'The %s field must only contain alpha-numeric characters.',
            alpha_dash: 'The %s field must only contain alpha-numeric characters, underscores, and dashes.',
            numeric: 'The %s field must contain only numbers.',
            integer: 'The %s field must contain an integer.',
            decimal: 'The %s field must contain a decimal number.',
            is_natural: 'The %s field must contain only positive numbers.',
            is_natural_no_zero: 'The %s field must contain a number greater than zero.',
            valid_ip: 'The %s field must contain a valid IP.',
            valid_base64: 'The %s field must contain a base64 string.',
            valid_credit_card: 'The %s field must contain a valid credit card number.',
            is_file_type: 'The %s field must contain only %s files.',
            valid_url: 'The %s field must contain a valid URL.'
        },
        callback: function(errors) {

        }
    };

    /*
     * Define the regular expressions that will be used
     */

    var ruleRegex = /^(.+?)\[(.+)\]$/,
        numericRegex = /^[0-9]+$/,
        integerRegex = /^\-?[0-9]+$/,
        decimalRegex = /^\-?[0-9]*\.?[0-9]+$/,
        emailRegex = /^[a-zA-Z0-9.!#$%&amp;'*+\-\/=?\^_`{|}~\-]+@[a-zA-Z0-9\-]+(?:\.[a-zA-Z0-9\-]+)*$/,
        alphaRegex = /^[a-zA-Z]+$/i,
        alphaNumericRegex = /^[a-zA-Z0-9]+$/i,
		alphaNumericDashRegex = /^[a-zA-Z0-9\s]+$/i,
        alphaDashRegex = /^[a-zA-Z0-9_\-\s]+$/i,
        naturalRegex = /^[0-9]+$/i,
        naturalNoZeroRegex = /^[1-9][0-9]*$/i,
        ipRegex = /^((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){3}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})$/i,
        base64Regex = /[^a-zA-Z0-9\/\+=]/i,
        numericDashRegex = /^[\d\-\s]+$/,
		numericSpaceRegex = /^[\d\s]+$/,
        urlRegex = /^((http|https):\/\/(\w+:{0,1}\w*@)?(\S+)|)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?$/;

	  // Array to hold the permitted card characteristics
	  var cardsRegEx = [
		  {name: "VISA", cardlength: /^(13|16)$/, regex: /^4[0-9]{12}(?:[0-9]{3})?$/},
		  {name: "MASTERCARD", cardlength: /^(16)$/, regex:  /^5[1-5][0-9]{14}$/},
		  {name: "DINERSCLUB", cardlength: /^(14|16)$/, regex: /^3(?:0[0-5]|[68][0-9])[0-9]{11}$/},
		  {name: "CARTEBLANCHE",cardlength: /^(14)$/, regex: /^(300|301|302|303|304|305)\d+$/},
		  {name: "AMEX",cardlength: /^(15)$/, regex: /^(34|37)\d+$/},
		  {name: "DISCOVER",cardlength: /^(16)$/, regex:  /^6(?:011|5[0-9]{2})[0-9]{12}$/},
		  {name: "JCB", cardlength: /^(16)$/, regex: /^(?:2131|1800|35\d{3})\d{11}$/},
		  {name: "ENROUTE", cardlength: /^(15)$/, regex: /^(2014|2149)\d+$/},
		  {name: "SOLO",cardlength: /^(16|18|19)$/,regex: /^(6334|6767)\d+$/},
		  {name: "SWITCH", cardlength: /^(16|18|19)$/, regex: /^(4903|4905|4911|4936|564182|633110|6333|6759)\d+$/},
		  {name: "MAESTRO", cardlength: /^(12|13|14|15|16|18|19)$/ , regex: /^(5018|5020|5038|5612|5893|6304|6759|6761|6762|6763|0604|6390)\d+$/},
		  {name: "VISAELECTRON", cardlength: /^(16)$/, regex: /^(4026|417500|4405|4508|4844|4913|4917)\d+$/},
		  {name: "LASERCARD", cardlength: /^(16|17|18|19)$/, regex: /^(6304|6706|6771|6709)\d+$/},
		  {name: "DANKORT", cardlength: /^(16)$/, regex: /^(5019)\d+$/},
		  {name: "INTERPAYMENT", cardlength: /^(16|17|18|19)$/, regex: /^(5019)\d+$/},
		  {name: "UNIONPAY", cardlength: /^(16|17|18|19)$/, regex: /^(62|88)\d+$/}
	  ];
	  
	  var cardsAllowedRegEx = [
			{name: "VISA", cardlength: /^(13|16)$/, regex: /^4[0-9]{12}(?:[0-9]{3})?$/},
			{name: "MASTERCARD", cardlength: /^(16)$/, regex:  /^5[1-5][0-9]{14}$/},
			{name: "MAESTRO", cardlength: /^(12|13|14|15|16|18|19)$/ , regex: /^(56|67)\d+$/},
			{name: "AMEX",cardlength: /^(15)$/, regex: /^(34|37)\d+$/}
	  ];

	  var getCard = function(cardNo){
		for (card in cardsAllowedRegEx) {
			card = cardsAllowedRegEx[card];
			if(card.regex.test(cardNo) && card.cardlength.test(cardNo.length)){
				return card;
			}
		}
		return null;
	  }
	  
	   var getCardLengthCheck = function(cardNo){
		for (card in cardsRegEx) {
			card = cardsRegEx[card];
			if(card.cardlength.test(cardNo.length)){
				return card;
			}
		}
		return null;
	  }
	  
	  var checkUKPostCode = function(toCheck) {
		  //Author:        John Gardner
		  // Permitted letters depend upon their position in the postcode.
		  var alpha1 = "[abcdefghijklmnoprstuwyz]";                       // Character 1
		  var alpha2 = "[abcdefghklmnopqrstuvwxy]";                       // Character 2
		  var alpha3 = "[abcdefghjkpmnrstuvwxy]";                         // Character 3
		  var alpha4 = "[abehmnprvwxy]";                                  // Character 4
		  var alpha5 = "[abdefghjlnpqrstuwxyz]";                          // Character 5
		  var BFPOa5 = "[abdefghjlnpqrst]";                               // BFPO alpha5
		  var BFPOa6 = "[abdefghjlnpqrstuwzyz]";                          // BFPO alpha6	  
		  // Array holds the regular expressions for the valid postcodes
		  var pcexp = new Array ();		  
		  // BFPO postcodes
		  pcexp.push (new RegExp ("^(bf1)(\\s*)([0-6]{1}" + BFPOa5 + "{1}" + BFPOa6 + "{1})$","i"));
		  // Expression for postcodes: AN NAA, ANN NAA, AAN NAA, and AANN NAA
		  pcexp.push (new RegExp ("^(" + alpha1 + "{1}" + alpha2 + "?[0-9]{1,2})(\\s*)([0-9]{1}" + alpha5 + "{2})$","i"));		  
		  // Expression for postcodes: ANA NAA
		  pcexp.push (new RegExp ("^(" + alpha1 + "{1}[0-9]{1}" + alpha3 + "{1})(\\s*)([0-9]{1}" + alpha5 + "{2})$","i"));
		  // Expression for postcodes: AANA  NAA
		  pcexp.push (new RegExp ("^(" + alpha1 + "{1}" + alpha2 + "{1}" + "?[0-9]{1}" + alpha4 +"{1})(\\s*)([0-9]{1}" + alpha5 + "{2})$","i"));		  
		  // Exception for the special postcode GIR 0AA
		  pcexp.push (/^(GIR)(\s*)(0AA)$/i);		  
		  // Standard BFPO numbers
		  pcexp.push (/^(bfpo)(\s*)([0-9]{1,4})$/i);		  
		  // c/o BFPO numbers
		  pcexp.push (/^(bfpo)(\s*)(c\/o\s*[0-9]{1,3})$/i);		  
		  // Overseas Territories
		  pcexp.push (/^([A-Z]{4})(\s*)(1ZZ)$/i);  
		  // Anguilla
		  pcexp.push (/^(ai-2640)$/i);
		  // Load up the string to check
		  var postCode = toCheck;
		  // Assume we're not going to find a valid postcode
		  var valid = false;		  
		  // Check the string against the types of post codes
		  for ( var i=0; i<pcexp.length; i++) {		  
			if (pcexp[i].test(postCode)) {		
			  // The post code is valid - split the post code into component parts
			  pcexp[i].exec(postCode); 
			  // Copy it back into the original string, converting it to uppercase and inserting a space 
			  // between the inward and outward codes
			  postCode = RegExp.$1.toUpperCase() + " " + RegExp.$3.toUpperCase();
			  // If it is a BFPO c/o type postcode, tidy up the "c/o" part
			  postCode = postCode.replace (/C\/O\s*/,"c/o ");
			  // If it is the Anguilla overseas territory postcode, we need to treat it specially
			  if (toCheck.toUpperCase() == 'AI-2640') {postCode = 'AI-2640'};
			  // Load new postcode back into the form element
			  valid = true;			  
			  // Remember that we have found that the code is valid and break from loop
			  break;
			}
		  }		  
		  // Return with either the reformatted valid postcode or the original invalid postcode
		  if (valid) {return postCode;} else return false;
		}
    /*
     * The exposed public object to validate a form:
     *
     * @param formNameOrNode - String - The name attribute of the form (i.e. <form name="myForm"></form>) or node of the form element
     * @param fields - Array - [{
     *     name: The name of the element (i.e. <input name="myField" />)
     *     display: 'Field Name'
     *     rules: required|matches[password_confirm]
     * }]
     * @param callback - Function - The callback after validation has been performed.
     *     @argument errors - An array of validation errors
     *     @argument event - The javascript event
     */

    var FormValidator = function(formNameOrNode, fields, callback) {
        this.callback = callback || defaults.callback;
        this.errors = [];
        this.fields = {};
        this.form = this._formByNameOrNode(formNameOrNode) || {};
        this.messages = {};
        this.handlers = {};
        this.conditionals = {};

        for (var i = 0, fieldLength = fields.length; i < fieldLength; i++) {
            var field = fields[i];
            // If passed in incorrectly, we need to skip the field.
            if ((!field.name && !field.names) || !field.rules) {
                continue;
            }
            /*
             * Build the master fields array that has all the information needed to validate
             */
            if (field.names) {
                for (var j = 0, fieldNamesLength = field.names.length; j < fieldNamesLength; j++) {
                    this._addField(field, field.names[j]);
                }
            } else {
                this._addField(field, field.name);
            }
        }

        /*
         * Attach an event callback for the form submission
         */
		/*
        var _onsubmit = this.form.onsubmit;

        this.form.onsubmit = (function(that) {
            return function(evt) {
                try {
                    return that._validateForm(evt) && (_onsubmit === undefined || _onsubmit());
                } catch(e) {}
            };
        })(this);
		*/
    },

    attributeValue = function (element, attributeName) {
        var i;

        if ((element.length > 0) && (element[0].type === 'radio' || element[0].type === 'checkbox')) {
            for (i = 0, elementLength = element.length; i < elementLength; i++) {
                if (element[i].checked) {
                    return element[i][attributeName];
                }
            }

            return;
        }

        return element[attributeName];
    };

    /*
     * @public
     * Sets a custom message for one of the rules
     */

    FormValidator.prototype.setMessage = function(rule, message) {
        this.messages[rule] = message;

        // return this for chaining
        return this;
    };

    /*
     * @public
     * Registers a callback for a custom rule (i.e. callback_username_check)
     */

    FormValidator.prototype.registerCallback = function(name, handler) {
        if (name && typeof name === 'string' && handler && typeof handler === 'function') {
            this.handlers[name] = handler;
        }

        // return this for chaining
        return this;
    };

    /*
     * @public
     * Registers a conditional for a custom 'depends' rule
     */

    FormValidator.prototype.registerConditional = function(name, conditional) {
        if (name && typeof name === 'string' && conditional && typeof conditional === 'function') {
            this.conditionals[name] = conditional;
        }

        // return this for chaining
        return this;
    };

    /*
     * @private
     * Determines if a form dom node was passed in or just a string representing the form name
     */

    FormValidator.prototype._formByNameOrNode = function(formNameOrNode) {
        return (typeof formNameOrNode === 'object') ? formNameOrNode : document.forms[formNameOrNode];
    };

    /*
     * @private
     * Adds a file to the master fields array
     */

    FormValidator.prototype._addField = function(field, nameValue)  {
        this.fields[nameValue] = {
            name: nameValue,
            display: field.display || nameValue,
            rules: field.rules,
            depends: field.depends,
			message : field.message || null,
			error : [],
			triggerOn : (!field.triggerOn || field.triggerOn === '' || field.triggerOn === undefined) ? [] : field.triggerOn.split("|"),
            id: null,
            type: null,
            value: null,
            checked: null
        };
		//Add the events List to the field Dynamically
		var evtList = this.fields[nameValue].triggerOn;
		if(typeof evtList != "undefined" && evtList != null && evtList.length > 0){			 
			 for (var et = 0;et < evtList.length;et++) {
				this.fields[nameValue][evtList[et]] = field[evtList[et]];
			 }
		}
    };

    /*
     * @private
     * Runs the validation.
     */
    FormValidator.prototype._validateForm = function(evt,actEvtValidate) {
        this.errors = [];

        for (var key in this.fields) {			
            if (this.fields.hasOwnProperty(key)) {
                var field = this.fields[key] || {},
                    element = this.form[field.name];
                if (element && element !== undefined) {
                    field.id = attributeValue(element, 'id');
                    field.type = (element.length > 0) ? element[0].type : element.type;
                    field.value = attributeValue(element, 'value');
                    field.checked = attributeValue(element, 'checked');
					

					if(typeof field.triggerOn != "undefined" && field.triggerOn != null && field.triggerOn.length > 0){
						 for (var et = 0;et < field.triggerOn.length;et++) {
							this._triggerEvents(element,field.triggerOn[et],field);
							if(actEvtValidate != "undefined" && actEvtValidate){
								this._activateEventsToValidate(element,field.triggerOn[et]);
							}
						 }
					}
					 else {
                        this._validateField(field);
                    }
                }
            }
        }

        if (typeof this.callback === 'function') {
            this.callback(this.errors,evt);
        }

        if ((null != evt) && this.errors.length > 0) {
            if (evt && evt.preventDefault) {
                evt.preventDefault();
            }else if (event) {
                // IE uses the global event variable
                event.returnValue = false;
            }
        }
		
        return this.errors;
    };

	FormValidator.prototype._executeFunctionByName = function(functionName, context /*, args */) {
		var args = Array.prototype.slice.call(arguments, 2);
		var namespaces = functionName.split(".");
		var func = namespaces.pop();
		for (var i = 0; i < namespaces.length; i++) {
			context = context[namespaces[i]];
		}
		return (context[func] != undefined) ? context[func].apply(context, args) : null;
	}
	
	FormValidator.prototype._bindEvent = function(el, eltype, handler) {		
        if (el.addEventListener) {el.addEventListener(eltype, handler(), false);} 
		else if (el.attachEvent) {el.attachEvent("on" + eltype, handler);}
		else {el["on" + eltype] = handler;}
    };
	
    FormValidator.prototype._unbindEvent = function(element, type, handler) {
        if (element.removeEventListener) {element.removeEventListener(type, handler(), false);} 
		else if (element.detachEvent) {element.detachEvent("on" + type, handler);}
		else {element["on" + type] = null;}
    };
	
    FormValidator.prototype._triggerEvents = function(element,evtType,field) {
		$(element).unbind(evtType,function(){
			field.evtTriggered =  false;
		});
		var formvalidateInst = this;
		$(element).bind(evtType,function(){
			field.id = attributeValue(element, 'id');
			field.type = (element.length > 0) ? element[0].type : element.type;
			field.value = attributeValue(element, 'value');
			field.checked = attributeValue(element, 'checked');
			field.error = [];
			field.evtTriggered =  true;
			formvalidateInst._validateField(field);
			if(field[evtType] != undefined)
				formvalidateInst._executeFunctionByName(evtType,field,field);
		});
        // return this for chaining
        return this;
    };

    FormValidator.prototype._activateEventsToValidate = function(element,evtType) {
		$(element).trigger(evtType);
        // return this for chaining
        return this;
    };
	
    /*
     * @private
     * Looks at the fields value and evaluates it against the given rules
     */

    FormValidator.prototype._validateField = function(field) {
        var rules = field.rules.split('|'),
            indexOfRequired = field.rules.indexOf('required'),
            isEmpty = (!field.value || field.value === '' || field.value === undefined);
        /*
         * Run through the rules and execute the validation methods as needed
         */
		
        for (var i = 0, ruleLength = rules.length; i < ruleLength; i++) {
            var method = rules[i],
                param = null,
                failed = false,
                parts = ruleRegex.exec(method);

            /*
             * If this field is not required and the value is empty, continue on to the next rule unless it's a callback.
             * This ensures that a callback will always be called but other rules will be skipped.
             */

            if (indexOfRequired === -1 && method.indexOf('!callback_') === -1 && isEmpty) {
                continue;
            }

            /*
             * If the rule has a parameter (i.e. matches[param]) split it out
             */

            if (parts) {
                method = parts[1];
                param = parts[2];
            }

            if (method.charAt(0) === '!') {
                method = method.substring(1, method.length);
            }

			 /*
                     * Run through the rules for each field.
                     * If the field has a depends conditional, only validate the field
                     * if it passes the custom function
                     */
			if (field.depends && typeof field.depends === "function") {
				if (!field.depends.call(this, field)) {
					failed=true;
				}
			} else if (field.depends && typeof field.depends === "string" && this.conditionals[field.depends]) {
				if (!this.conditionals[field.depends].call(this,field)) {
					failed = true;
				}
			}
					
            /*
             * If the hook is defined, run it to find any validation errors
             */
            if (typeof this._hooks[method] === 'function') {
                if (!this._hooks[method].apply(this, [field, param])) {
                    failed = true;
                }
            } else if (method.substring(0, 9) === 'callback_') {
                // Custom method. Execute the handler if it was registered
                method = method.substring(9, method.length);

                if (typeof this.handlers[method] === 'function') {
                    if (this.handlers[method].apply(this, [field.value, param]) === false) {
                        failed = true;
                    }
                }
            }
			
            /*
             * If the hook failed, add a message to the errors array
             */
			
			
            if (failed) {	
                // Make sure we have a message for this rule
				var source = field[method+"_msg"] || field.message || this.messages[field.name + '.' + method] || this.messages[method] || defaults.messages[method],
                    message = 'An error has occurred with the ' + field.display + ' field.';

                if (source) {
                    message = source.replace('%s', field.display);

                    if (param) {
                        message = message.replace('%s', (this.fields[param]) ? this.fields[param].display : param);
                    }
                }
				
				if((typeof field.triggerOn != "undefined" && field.triggerOn != null) && 
				   ((field.triggerOn.length > 0 && field.evtTriggered != undefined && field.evtTriggered) ||
				   (field.triggerOn.length==0 && field.evtTriggered == undefined))){
					field.error.push({
						id: field.id,
						name: field.name,
						message: message,
						rule: method
					});
					
					this.errors.push({
						id: field.id,
						name: field.name,
						message: message,
						rule: method
					});
				}
                // Break out so as to not spam with validation errors (i.e. required and valid_email)
                break;
            }
        }
    };

    /*
     * @private
     * Object containing all of the validation hooks
     */
	 var inArray = function(array, item) {
		  for (var i = 0; i < array.length; i++) {
			if (array[i] === item)
			  return i;
		  }
		  return -1;
	};

    FormValidator.prototype._hooks = {
        required: function(field) {
            var value = field.value;

            if ((field.type === 'checkbox') || (field.type === 'radio')) {
                return (field.checked === true);
            }
			
            return (value !== null && value !== '');
        },

        "default": function(field, defaultName){
            return field.value !== defaultName;
        },

        matches: function(field, matchName) {
            var el = this.form[matchName];

            if (el) {
                return field.value === el.value;
            }

            return false;
        },

        valid_email: function(field) {
            return emailRegex.test(field.value);
        },

        valid_emails: function(field) {
            var result = field.value.split(",");

            for (var i = 0, resultLength = result.length; i < resultLength; i++) {
                if (!emailRegex.test(result[i])) {
                    return false;
                }
            }

            return true;
        },

        min_length: function(field, length) {
            if (!numericRegex.test(length)) {
                return false;
            }

            return (field.value.length >= parseInt(length, 10));
        },

        max_length: function(field, length) {
            if (!numericRegex.test(length)) {
                return false;
            }

            return (field.value.length <= parseInt(length, 10));
        },

        exact_length: function(field, length) {
            if (!numericRegex.test(length)) {
                return false;
            }

            return (field.value.length === parseInt(length, 10));
        },

        greater_than: function(field, param) {
            if (!decimalRegex.test(field.value)) {
                return false;
            }

            return (parseFloat(field.value) > parseFloat(param));
        },

        less_than: function(field, param) {
            if (!decimalRegex.test(field.value)) {
                return false;
            }

            return (parseFloat(field.value) < parseFloat(param));
        },

        alpha: function(field) {
            return (alphaRegex.test(field.value));
        },

        alpha_numeric: function(field) {
            return (alphaNumericRegex.test(field.value));
        },

        alpha_dash: function(field) {
            return (alphaDashRegex.test(field.value));
        },

        alpha_numeric_dash: function(field) {
            return (alphaNumericDashRegex.test(field.value));
        },		

        numeric: function(field) {
            return (numericRegex.test(field.value));
        },
		
		numeric_dash: function(field) {
            return (numericDashRegex.test(field.value));
        },

        integer: function(field) {
            return (integerRegex.test(field.value));
        },

        decimal: function(field) {
            return (decimalRegex.test(field.value));
        },

        is_natural: function(field) {
            return (naturalRegex.test(field.value));
        },

        is_natural_no_zero: function(field) {
            return (naturalNoZeroRegex.test(field.value));
        },

        valid_ip: function(field) {
            return (ipRegex.test(field.value));
        },

        valid_base64: function(field) {
            return (base64Regex.test(field.value));
        },

        valid_url: function(field) {
            return (urlRegex.test(field.value));
        },		
		uk_msisdn : function(field){
			if(!(/^(((\+?)44)|07)[0-9\s]+$/.test(field.value)))return false;
			var strippedField = field.value.replace(/\D/g, "");
			strippedField= strippedField.replace(/^(44|0)/g,"");
			return ((strippedField.length == 10));
		},
		uk_postcode : function(field){			
			var strippedField = field.value.replace(/\s/g, "");
			return (checkUKPostCode(strippedField));
		},		
		uk_voucher : function(field){
			var strippedField = field.value.replace(/\D/g, "");
			return ((strippedField.length == 16));
		},		
        valid_credit_card: function(field){
            // Luhn Check Code from https://gist.github.com/4075533
            // accept only digits, dashes or spaces
            if (!numericDashRegex.test(field.value)) return false;

            // The Luhn Algorithm. It's so pretty.
            var nCheck = 0, nDigit = 0, bEven = false;
            var strippedField = field.value.replace(/\D/g, "");

            for (var n = strippedField.length - 1; n >= 0; n--) {
                var cDigit = strippedField.charAt(n);
                nDigit = parseInt(cDigit, 10);
                if (bEven) {
                    if ((nDigit *= 2) > 9) nDigit -= 9;
                }

                nCheck += nDigit;
                bEven = !bEven;
            }

            return (nCheck % 10) === 0;
        },
		uk_credit_card : function(field){
			if (!numericSpaceRegex.test(field.value)) return false;
			if(/^(\s+)[0-9\s]+$/.test(field.value)) return false;
			var strippedField = field.value.replace(/\D/g, "");
			var allowed_cards = ["VISA","MASTERCARD","MAESTRO","AMEX"];
			var card = getCard(strippedField);
			if(null != card && (inArray(allowed_cards,card.name) != -1)){
				return this._hooks.valid_credit_card(field);
			}
			return false;
		},
		uk_credit_card_checking : function(field){
			if (!numericSpaceRegex.test(field.value)) return false;
			if(/^(\s+)[0-9\s]+$/.test(field.value)) return false;
			var strippedField = field.value.replace(/\D/g, "");
			var card = getCardLengthCheck(strippedField);
			if(null != card){
				return this._hooks.valid_credit_card(field);
			}
			return false;
		},
        is_file_type: function(field,type) {
            if (field.type !== 'file') {
                return true;
            }

            var ext = field.value.substr((field.value.lastIndexOf('.') + 1)),
                typeArray = type.split(','),
                inArray = false,
                i = 0,
                len = typeArray.length;

            for (i; i < len; i++) {
                if (ext == typeArray[i]) inArray = true;
            }

            return inArray;
        }
    };

    window.FormValidator = FormValidator;

})(window, document);